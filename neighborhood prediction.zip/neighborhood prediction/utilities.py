from networkx import expected_degree_graph
import numpy as np
import torch
from gurobipy import GRB
from uc_class import UC
import os
from torch_geometric.data import HeteroData
import collections
import time
import gurobipy as gp

# def get_graph(m):
#     mvars = m.getVars()
#     constrs = m.getConstrs()
#     b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
#     coo = m.getA().tocoo()
#     # values = coo.data
#     # indices = np.vstack((coo.row, coo.col))
#     v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
#     v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
#     v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
#     v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
#     v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
#     v5 = b_vars.clone().reshape(-1,1)
#     v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1).float()
#     c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
#     c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
#     c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
#     c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
#     c_nodes = torch.cat((c0,c1,c2,c3),1).float()

#     cons=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']

#     graph = HeteroData()

#     n=len(mvars)
#     T=24
#     N=int(sum(b_vars)/T)

#     if N*T == n/3:
        
#         graph['u'].x = v_nodes[:N*T]
#         graph['p'].x = v_nodes[N*T:2*N*T]
#         graph['s'].x = v_nodes[2*N*T:3*N*T]

#         r = 0
#         idx=0
#         for l, c in enumerate(constrs):
#             if cons[idx] in c.ConstrName and l != len(constrs) - 1:
#                 continue
#             if l == len(constrs) - 1:
#                 l+=1
#             graph[cons[idx]].x = c_nodes[r:l]
#             uindice = []
#             pindice = []
#             sindice = []
#             uvalues = []
#             pvalues = []
#             svalues = []
#             for constr, variable, value in zip(coo.row, coo.col, coo.data):
#                 if r <= constr < l:
#                     if variable < N*T:
#                         uindice.append((variable, constr-r))
#                         uvalues.append(value)
#                     elif N*T <= variable < 2*N*T:
#                         pindice.append((variable-N*T, constr-r))
#                         pvalues.append(value)
#                     elif variable >= 2*N*T:
#                         sindice.append((variable-2*N*T, constr-r))
#                         svalues.append(value)

#             uindice = np.array(uindice).T
#             pindice = np.array(pindice).T
#             sindice = np.array(sindice).T
#             uvalues = torch.tensor(uvalues, dtype=torch.float32).reshape(-1,1)
#             pvalues = torch.tensor(pvalues, dtype=torch.float32).reshape(-1,1)
#             svalues = torch.tensor(svalues, dtype=torch.float32).reshape(-1,1)

#             if uindice.size:
#                 graph['u','v2c',cons[idx]].edge_index = torch.from_numpy(uindice)
#                 graph['u','v2c',cons[idx]].edge_attr = uvalues
#                 graph[cons[idx],'c2v','u'].edge_index = torch.from_numpy(uindice[[1,0]])
#                 graph[cons[idx],'c2v','u'].edge_attr = uvalues
#             if pindice.size:
#                 graph['p','v2c',cons[idx]].edge_index = torch.from_numpy(pindice)
#                 graph['p','v2c',cons[idx]].edge_attr = pvalues
#                 graph[cons[idx],'c2v','p'].edge_index = torch.from_numpy(pindice[[1,0]])
#                 graph[cons[idx],'c2v','p'].edge_attr = pvalues
#             if sindice.size:                
#                 graph['s','v2c',cons[idx]].edge_index = torch.from_numpy(sindice)
#                 graph['s','v2c',cons[idx]].edge_attr = svalues
#                 graph[cons[idx],'c2v','s'].edge_index = torch.from_numpy(sindice[[1,0]])
#                 graph[cons[idx],'c2v','s'].edge_attr = svalues
#             r = l
#             idx += 1
#         graph
#         return graph


def get_graph(m):
    constraints=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
    variables=['u','p','s']
    A = m.getA()
    rows, cols = A.shape
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = A.tocoo()
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1).float()
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1).float()

    tot=int(cols/3)
    col_slides=collections.defaultdict(int)
    for v in variables:
        col_slides[v]=int(tot)
    row_slides=[]
    graph = HeteroData()

    row_slides = collections.defaultdict(int)
    cons = m.getConstrs()
    t=0
    coc=0
    for c in cons:
        name=constraints[t]
        while name not in c.ConstrName:
            t+=1
            name=constraints[t]
        if t>=len(constraints):
            break
        row_slides[name]+=1
    lastv=0
    for v in variables:
        graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
        lastv+=col_slides[v]
    lastc=0
    for c in constraints:
        graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
        lastc+=row_slides[c]
    lastr=0
    for c in constraints:
        lastc=0
        for v in variables:
            mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
            lastc+=col_slides[v]
            values = mtx.data
            if len(values)==0:
                continue
            row_indices = mtx.row
            col_indices = mtx.col
            indices = np.vstack((row_indices, col_indices))
            graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
            graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
        lastr+=row_slides[c]

    return graph





def get_norm(ori_tensor):
    ori_tensor = ori_tensor.reshape(-1,1)
    norm = torch.norm(ori_tensor, keepdim=True)
    norm_tensor = (ori_tensor/(norm+1e-6))
    return torch.cat((ori_tensor, norm_tensor), dim=1)

def get_Tripartite_graph_lp(m):
    r=m.relax()
    r.setParam('OutputFlag', 0)
    r.optimize()
    rvars=r.getVars()
    # constraints=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
    # variables=['u','p','s']
    variables=[]
    constraints=[]
    mvars = m.getVars()
    constrs = m.getConstrs()
    for v in mvars:
        vname = v.VarName.split('[')[0]
        if vname not in variables:
            variables.append(vname)
    for c in constrs:
        cname = c.ConstrName.split('[')[0]
        cname = cname.rstrip('0123456789')
        if cname not in constraints:
            constraints.append(cname)
    A = m.getA()
    rows, cols = A.shape
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = A.tocoo()
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v6 = torch.tensor([v.x for v in rvars]).reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5,v6),1).float()
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1).float()

    tot=int(cols/len(variables))
    col_slides=collections.defaultdict(int)
    for v in variables:
        col_slides[v]=int(tot)
    row_slides=[]
    graph = HeteroData()

    row_slides = collections.defaultdict(int)
    cons = m.getConstrs()
    t=0
    coc=0
    for c in cons:
        name=constraints[t]
        while name not in c.ConstrName:
            t+=1
            name=constraints[t]
        if t>=len(constraints):
            break
        row_slides[name]+=1
    lastv=0
    for v in variables:
        graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
        lastv+=col_slides[v]
    lastc=0
    for c in constraints:
        graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
        lastc+=row_slides[c]
    lastr=0
    for c in constraints:
        lastc=0
        for v in variables:
            mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
            lastc+=col_slides[v]
            values = mtx.data
            if len(values)==0:
                continue
            row_indices = mtx.row
            col_indices = mtx.col
            indices = np.vstack((row_indices, col_indices))
            graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
            graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
        lastr+=row_slides[c]

    
    #o节点
    graph['obj'].x = torch.tensor([r.objVal]).reshape(1,-1)
    con_indice=[]
    con_attr=[]
    idx=0
    t=0
    for c in r.getConstrs():
        name=constraints[t]
        while name not in c.ConstrName:
            if 'edge_attr' in graph['obj','o2c',name]:
                graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
                graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
                graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
            t+=1
            name=constraints[t]
            idx=0
            con_indice=[]
            con_attr=[]
        if t>=len(constraints):
            break
        
        if c.Slack < 1e-6:
            con_indice.append((0,idx))
            con_attr.append(c.RHS)
        idx+=1
    graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
    graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
    graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
    #加入ov边
    for i,v in enumerate(['u','p','s']):
        graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1,tot, dtype=torch.int64), torch.arange(0,tot).unsqueeze(0)), 0)
        graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, tot).unsqueeze(0), torch.zeros(1, tot, dtype=torch.int64)), 0)
        graph['obj','o2v',v].edge_attr = get_norm(v0[tot*i:tot*(i+1)])

    return graph

def get_Tripartite_graph(m):
    constraints=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
    variables=['u','p','s']
    A = m.getA()
    rows, cols = A.shape
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = A.tocoo()
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1).float()
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1).float()

    tot=int(cols/3)
    col_slides=collections.defaultdict(int)
    for v in variables:
        col_slides[v]=int(tot)
    row_slides=[]
    graph = HeteroData()

    row_slides = collections.defaultdict(int)
    cons = m.getConstrs()
    t=0
    coc=0
    for c in cons:
        name=constraints[t]
        while name not in c.ConstrName:
            t+=1
            name=constraints[t]
        if t>=len(constraints):
            break
        row_slides[name]+=1
    lastv=0
    for v in variables:
        graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
        lastv+=col_slides[v]
    lastc=0
    for c in constraints:
        graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
        lastc+=row_slides[c]
    lastr=0
    for c in constraints:
        lastc=0
        for v in variables:
            mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
            lastc+=col_slides[v]
            values = mtx.data
            if len(values)==0:
                continue
            row_indices = mtx.row
            col_indices = mtx.col
            indices = np.vstack((row_indices, col_indices))
            graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
            graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
        lastr+=row_slides[c]

    r=m.relax()
    r.setParam('OutputFlag', 0)
    r.optimize()
    #o节点
    graph['obj'].x = torch.tensor([r.objVal]).reshape(-1,1)
    con_indice=[]
    con_attr=[]
    idx=0
    t=0
    for c in r.getConstrs():
        name=constraints[t]
        while name not in c.ConstrName:
            if 'edge_attr' in graph['obj','o2c',name]:
                graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
                graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
                graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
            t+=1
            name=constraints[t]
            idx=0
            con_indice=[]
            con_attr=[]
        if t>=len(constraints):
            break
        
        if c.Slack < 1e-6:
            con_indice.append((0,idx))
            con_attr.append(c.RHS)
        idx+=1
    graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
    graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
    graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
    #加入ov边
    for i,v in enumerate(['u','p','s']):
        graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1,tot, dtype=torch.int64), torch.arange(0,tot).unsqueeze(0)), 0)
        graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, tot).unsqueeze(0), torch.zeros(1, tot, dtype=torch.int64)), 0)
        graph['obj','o2v',v].edge_attr = get_norm(v0[tot*i:tot*(i+1)])

    return graph

def get_Tripartite_graph_lp_with_sol(m_o,sol):
    m=m_o.copy()
    r=m.relax()
    r.setParam('OutputFlag', 0)
    rvars=r.getVars()
    mvars = m.getVars()
    constrs = m.getConstrs()
    rconstrs = r.getConstrs()
    A = m.getA()
    coo = A.tocoo()
    
    m_u=mvars[:len(sol)]
    m.addConstrs((m_u[i] == sol[i] for i in range(len(sol))), name='fixed')
    m.update()
    m.optimize()
    r.addConstrs((rvars[i] == sol[i] for i in range(len(sol))), name='fixed')
    r.update()
    r.optimize()
    constraints=[]
    variables=[]
    for v in mvars:
        vname = v.VarName.split('[')[0]
        if vname not in variables:
            variables.append(vname)
    for c in constrs:
        cname = c.ConstrName.split('[')[0]
        cname = cname.rstrip('0123456789')
        if cname not in constraints and cname!='fixed':
            constraints.append(cname)

    

    v0 = torch.tensor([v.Obj for v in mvars]).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars]).reshape(-1,1)#最关键变量
    v6 = torch.tensor([1 if v.vType == 'B' else 0 for v in mvars]).reshape(-1,1)
    v7 = torch.tensor([v.x for v in mvars]).reshape(-1,1)
    v8 = torch.tensor([v.lb for v in mvars]).reshape(-1,1)
    v9 = torch.tensor([v.ub for v in mvars]).reshape(-1,1)
    v10 = torch.tensor([1 if v.lb==v.x else 0 for v in mvars]).reshape(-1,1)
    v11 = torch.tensor([1 if v.ub==v.x else 0 for v in mvars]).reshape(-1,1)
    v12 = torch.tensor([min(v.ub-v.x,v.x-v.lb) for v in mvars]).reshape(-1,1)
    v13 = torch.tensor([v.x*v.Obj for v in mvars]).reshape(-1,1)
    
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13),1).float()

    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c4 = torch.tensor([c.Slack for c in constrs]).reshape(-1,1)
    c5 = torch.tensor([c.Pi for c in rconstrs]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3,c4,c5),1).float()

    tot=len(sol)
    col_slides=collections.defaultdict(int)
    for v in variables:
        col_slides[v]=int(tot)
    row_slides=[]
    graph = HeteroData()

    row_slides = collections.defaultdict(int)
    t=0
    for c in constrs:
        name=constraints[t]
        while name not in c.ConstrName:
            t+=1
            name=constraints[t]
        if t>=len(constraints):
            break
        row_slides[name]+=1
    lastv=0
    for v in variables:
        graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
        lastv+=col_slides[v]
    lastc=0
    for c in constraints:
        graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
        lastc+=row_slides[c]
    lastr=0
    for c in constraints:
        lastc=0
        for v in variables:
            mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
            lastc+=col_slides[v]
            values = mtx.data
            if len(values)==0:
                continue
            row_indices = mtx.row
            col_indices = mtx.col
            indices = np.vstack((row_indices, col_indices))
            graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
            graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
        lastr+=row_slides[c]

    #o节点
    # print(r.status,m.status)
    
    graph['obj'].x = torch.tensor([r.objVal,m.objVal]).reshape(-1,1)
    con_indice=[]
    con_attr=[]
    idx=0
    t=0
    for c in rconstrs:
        name=constraints[t]
        while name not in c.ConstrName:
            if 'edge_attr' in graph['obj','o2c',name]:
                graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
                graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
                graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
            t+=1
            name=constraints[t]
            idx=0
            con_indice=[]
            con_attr=[]
        if t>=len(constraints):
            break
        
        if c.Slack < 1e-6:
            con_indice.append((0,idx))
            con_attr.append(c.RHS)
        idx+=1
    graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
    graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
    graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
    #加入ov边
    for i,v in enumerate(['u','p','sc']):
        graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1,tot, dtype=torch.int64), torch.arange(0,tot).unsqueeze(0)), 0)
        graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, tot).unsqueeze(0), torch.zeros(1, tot, dtype=torch.int64)), 0)
        graph['obj','o2v',v].edge_attr = get_norm(v0[tot*i:tot*(i+1)])

    return graph



def restore_initial(ans,p0,rd,sd,on_off,on,off):#-1表示不可开机
    N=ans.shape[0]
    T=ans.shape[1]
    for i in range(N):
        if on_off[i]<0:
            for t in range(off[i]+on_off[i]):#还需关机
                ans[i][t]=-1
        elif on_off[i]>0:
            for t in range(on[i]-on_off[i]):#还需开机
                ans[i][t]=1
        if p0[i]>sd[i]:#最快下坡还需开机
            # print((p0[i]-sd[i]+rd[i]-1)//rd[i])
            for t in range(int((p0[i]-sd[i]+rd[i]-1)//rd[i])):#向上取整
                ans[i][t]=1
        if on_off[i]<0 and -on_off[i]<off[i]:
            res = off[i]+on_off[i]
            for t in range(res):
                ans[i][t]=-1
        if on_off[i]>0 and on_off[i]<on[i]:
            res = on[i]-on_off[i]
            for t in range(res):
                ans[i][t]=1
    return ans

def restore_spin(ans,spin,dt,pmax):#可以接受小数与负数#后面考虑先开预测值大的机组
    N=ans.shape[0]
    T=ans.shape[1]
    for t in range(T):
        cur_max = 0
        for i in range(N):
            if ans[i][t]>=1-1e-5:
                cur_max+=pmax[i]
        
        if cur_max<spin[t]+dt[t]:
            p_list=[]
            for i in range(N):
                if ans[i][t]>=0 and ans[i][t]!=1:
                    p_list.append((ans[i,t],i))
            p_list.sort(key=lambda x:x[0],reverse=True)
            for p,i in p_list:
                cur_max+=pmax[i]
                ans[i][t]=1
                if cur_max>=spin[t]+dt[t]:
                    break
    return ans

def restore_on_off(ans,on_off,on,off):#可以接受小数与负数
    N=ans.shape[0]
    T=ans.shape[1]
    for i in range(N):
        t=0
        while t<T:#开机时长不够
            cnt1=0
            l=0
            while t+l<T and ans[i,t+l]==1:
                l+=1
                cnt1+=1
            if t+l>=T:
                break
            if cnt1>0 and t==0:
                cnt1+=max(0,on_off[i])
            if cnt1>0 and cnt1<on[i]:
                res = on[i]-cnt1
                dealed=0
                for ll in range(1,res+1):#往前开，遇到-1，1就停止
                    idx = t-ll
                    if idx<0 or ans[i,idx]==-1 or ans[i,idx]==1:
                        break
                    dealed+=1
                    ans[i,idx]=1
                res-=dealed
                for ll in range(1,res+1):#往后开不可能遇到-1，遇到1停止
                    idx = t+l+ll
                    if idx>=T or ans[i,idx]==1:
                        break
                    ans[i,idx]=1
            t+=l
            while t<T and ans[i,t]!=1:
                t+=1
        t=0
        while t<T:#关机时长不够
            cnt0=0
            l=0
            while t+l<T and ans[i,t+l]<1:
                l+=1
                cnt0+=1
            if t+l>=T:
                break
            if cnt0>0 and t==0:
                cnt0+=max(0,-on_off[i])

            if cnt0>0 and cnt0<off[i]:
                
                for ll in range(l):
                    ans[i,t+ll]=1
            t+=l
            while t<T and ans[i,t]>=1:
                t+=1
    return ans

def restore_shutdown(ans,m):
    N=ans.shape[0]
    T=ans.shape[1]
    
    r=m.relax()
    for i in range(N):
        for t in range(T):
            r.addConstr(m.getVarByName(f'u[{i},{t}]')==ans[i,t])
    r.optimize()

def early_startup(ans,res,t,l2r,su):
    N=ans.shape[0]
    #开机向前延长且前面满足最小开机时间
    sum=0
    for i in range(N):
        if l2r[i,t]<0:
            res-=su[i]
            sum+=su[i]
            ans[i,t]=1
        if res<=0:
            break
    return ans,sum


def delay_shutdown(ans,res,t,r2l,sd):
    N=ans.shape[0]
    #开机向后延长且后面满足最小开机时间
    sum=0
    for i in range(N):
        if r2l[i,t]<0:
            res-=sd[i]
            sum+=sd[i]
            ans[i,t]=1
        if res<=0:
            break
    return ans,sum

        

def com_cont_on_off(ans,on_off,off):
    N=ans.shape[0]
    T=ans.shape[1]
    r2l_off = np.zeros_like(ans)#表示还需要关机几个时段，0以下表示可以开机
    l2r_off = np.zeros_like(ans)#表示还需要关机几个时段，0以下表示可以开机
    for i in range(N):
        if on_off[i]<0:
            l2r_off[i,0]=off[i]+on_off[i]-1
        elif ans[i,0]<=0:
            l2r_off[i,0]=off[i]-1
        for t in range(1,T):
            if ans[i,t-1]<1 and ans[i,t]<1:
                l2r_off[i,t]=l2r_off[i,t-1]-1
            elif ans[i,t-1]==1 and ans[i,t]<1:
                l2r_off[i,t]=off[i]-1
    for i in range(N):
        if ans[i,T-1]<1:
            r2l_off[i,T-1]=-1
        for t in range(T-2,-1,-1):
            if ans[i,t+1]<1 and ans[i,t]<1:
                r2l_off[i,t]=r2l_off[i,t+1]-1
            elif ans[i,t+1]==1 and ans[i,t]<1:
                r2l_off[i,t]=off[i]-1
    return r2l_off,l2r_off

def restore_ramp(u_close,Dt,Ui0,Pi0,Pidown,Piup,ThPimin,ThPimax,Pistartup,Pishutdown,on_off,off):
    u = u_close.copy()
    u[u < 0.9+(1e-5)] = 0
    N=u.shape[0]
    T=u.shape[1]
    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.start()
        m = gp.Model(env=env)
    p = m.addVars(N, T, vtype=GRB.CONTINUOUS, name='p')

    m.addConstrs((u[i,t]*ThPimin[i] - p[i,t] <= 0  for i in range(N) for t in range (T)), name="Unit_generation_limits1" )
    m.addConstrs((p[i,t] <= u[i,t]*ThPimax[i]  for i in range(N) for t in range (T)), name="Unit_generation_limits2" )
    m.addConstrs((p[i,t]-(p[i,t-1]if t>0 else Pi0[i]) <= (u[i,t-1] if t>0 else Ui0[i])*Piup[i] + (u[i,t]-(u[i,t-1] if t>0 else Ui0[i]))*Pistartup[i] +(1-u[i,t])*ThPimax[i]  for i in range(N) for t in range(T)),name="Ramp_rate_limits1" )
    m.addConstrs(((p[i,t-1]if t>0 else Pi0[i])-p[i,t] <= u[i,t]*Pidown[i] + ((u[i,t-1] if t>0 else Ui0[i])-u[i,t])*Pishutdown[i] +(1-(u[i,t-1] if t>0 else Ui0[i]))*ThPimax[i]  for i in range(N) for t in range(T)),name="Ramp_rate_limits2")

    m.addConstrs((gp.quicksum(p[i, t] for i in range(N)) - Dt[t]  <= 0 for t in range(T)),name="Power_balance_constrains")

    m.setObjective(gp.quicksum(Dt[t] - gp.quicksum(p[i,t] for i in range(N)) for t in range(T)), GRB.MINIMIZE)
    m.update()        
    m.optimize()
    p_sum=[0]*T
    for i in range(N):
        for t in range(T):
            p_sum[t]+=p[i,t].x
    r2l,l2r = com_cont_on_off(u_close,on_off,off)
    #低成本修复爬坡，不保证完成修复
    for t in range(T):
        if p_sum[t]+1e-5<Dt[t]:#ans,res,t,r2l,sd
            u_close,res = delay_shutdown(u_close,Dt[t]-p_sum[t],t,r2l,Pishutdown)
            p_sum[t]+=res
    for t in range(T-1,-1,-1):
        if p_sum[t]+1e-5<Dt[t]:
            u_close,res = early_startup(u_close,Dt[t]-p_sum[t],t,l2r,Pistartup)
            p_sum[t]+=res
    #高成本修复爬坡，保证完成修复
    for t in range(T):
        if p_sum[t]+1e-5<Dt[t]:
            # for i in range(N-1,-1,-1):                #按优先顺序法固定
            #     if u_close[i,t]>=0 and u_close[i,t]<1:#不能开启必关机组
            #         u_close[i,t]=1                      #后面考虑先开预测值大的机组
            #         p_sum[t]+=Pistartup[i]
            #         if p_sum[t]>=Dt[t]:
            #             break
            p_list=[]
            for i in range(N):
                if u_close[i,t]>=0 and u_close[i,t]<1:
                    p_list.append((u_close[i,t],i))
            p_list.sort(key=lambda x:x[0],reverse=True)
            for p,i in p_list:
                u_close[i,t]=1
                p_sum[t]+=Pistartup[i]
                if p_sum[t]>=Dt[t]:
                    break
    return u_close

# def get_Tripartite_graph_old(m):
#     mvars = m.getVars()
#     constrs = m.getConstrs()
#     b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
#     coo = m.getA().tocoo()
#     # values = coo.data
#     # indices = np.vstack((coo.row, coo.col))
#     v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
#     v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
#     v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
#     v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
#     v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
#     v5 = b_vars.clone().reshape(-1,1)
#     v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1).float()
#     c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
#     c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
#     c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
#     c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
#     c_nodes = torch.cat((c0,c1,c2,c3),1).float()

#     cons=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']

#     graph = HeteroData()

#     n=len(mvars)
#     T=24
#     N=int(sum(b_vars)/T)

#     if N*T == n/3:
        
#         graph['u'].x = v_nodes[:N*T]
#         graph['p'].x = v_nodes[N*T:2*N*T]
#         graph['s'].x = v_nodes[2*N*T:3*N*T]

#         r = 0
#         idx=0
#         for l, c in enumerate(constrs):
#             if cons[idx] in c.ConstrName and l != len(constrs) - 1:
#                 continue
#             if l == len(constrs) - 1:
#                 l+=1
#             graph[cons[idx]].x = c_nodes[r:l]
#             uindice = []
#             pindice = []
#             sindice = []
#             uvalues = []
#             pvalues = []
#             svalues = []
#             for constr, variable, value in zip(coo.row, coo.col, coo.data):
#                 if r <= constr < l:
#                     if variable < N*T:
#                         uindice.append((variable, constr-r))
#                         uvalues.append(value)
#                     elif N*T <= variable < 2*N*T:
#                         pindice.append((variable-N*T, constr-r))
#                         pvalues.append(value)
#                     elif variable >= 2*N*T:
#                         sindice.append((variable-2*N*T, constr-r))
#                         svalues.append(value)
                        
#             uindice = np.array(uindice).T
#             pindice = np.array(pindice).T
#             sindice = np.array(sindice).T
#             uvalues = torch.tensor(uvalues, dtype=torch.float32).reshape(-1,1)
#             pvalues = torch.tensor(pvalues, dtype=torch.float32).reshape(-1,1)
#             svalues = torch.tensor(svalues, dtype=torch.float32).reshape(-1,1)
#             if uindice.size:
#                 graph['u','v2c',cons[idx]].edge_index = torch.from_numpy(uindice)
#                 graph['u','v2c',cons[idx]].edge_attr = get_norm(uvalues)
#                 graph[cons[idx],'c2v','u'].edge_index = torch.from_numpy(uindice[[1,0]])
#             if pindice.size:
#                 graph['p','v2c',cons[idx]].edge_index = torch.from_numpy(pindice)
#                 graph['p','v2c',cons[idx]].edge_attr = get_norm(pvalues)
#                 graph[cons[idx],'c2v','p'].edge_index = torch.from_numpy(pindice[[1,0]])
#             if sindice.size:                
#                 graph['s','v2c',cons[idx]].edge_index = torch.from_numpy(sindice)
#                 graph['s','v2c',cons[idx]].edge_attr = get_norm(svalues)
#                 graph[cons[idx],'c2v','s'].edge_index = torch.from_numpy(sindice[[1,0]])
#             r = l
#             idx += 1
#         #加入oc边
#         con_indice = collections.defaultdict(list)
#         con_attr = collections.defaultdict(list)
#         con_index = collections.defaultdict(int)
#         r = m.relax()
#         r.setParam('OutputFlag', 0)
#         r.optimize()
#         #o节点
#         graph['obj'].x = torch.tensor([r.objVal]).reshape(-1,1)
#         for c in r.getConstrs():
#             for con_name in cons:
#                 if con_name in c.ConstrName:
#                     cur_name = con_name
#                     break

#             if c.Slack < 1e-6:
#                 con_indice[cur_name].append((0,con_index[cur_name]))
#                 con_attr[cur_name].append(c.RHS)
#                 con_index[cur_name]+=1
#         for con_name in cons:
#             if con_indice[con_name]:
#                 graph['obj','o2c',con_name].edge_index = torch.tensor(con_indice[con_name], dtype=torch.int64).T
#                 graph[con_name,'c2o','obj'].edge_index = torch.tensor(con_indice[con_name], dtype=torch.int64).T[[1,0]]
                
#                 graph['obj','o2c',con_name].edge_attr = get_norm(torch.tensor(con_attr[con_name]))
            
            
#         #加入ov边
#         for i,v in enumerate(['u','p','s']):
#             graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1, N*T, dtype=torch.int64), torch.arange(0, N*T).unsqueeze(0)), 0)
#             graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, N*T).unsqueeze(0), torch.zeros(1, N*T, dtype=torch.int64)), 0)
#             graph['obj','o2v',v].edge_attr = get_norm(v0[N*T*i:N*T*(i+1)])
#         return graph
def restore(sol, uc, data):
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    shut_down = uc.Pishutdown
    startup = uc.Pistartup
    on = uc.ThTime_on_min
    off = uc.ThTime_off_min
    pmax = uc.ThPimax
    pmin = uc.ThPimin
    ramp_up = uc.Piup
    ramp_down = uc.Pidown
    sol = restore_initial(sol,p0,ramp_down,shut_down,on_off,on,off)
    sol[sol >= 0.9] = 1
    sol = restore_spin(sol,Spin,Dt,pmax)
    sol = restore_on_off(sol,on_off,on,off)
    sol = restore_ramp(sol,Dt,u0,p0,ramp_down,ramp_up,pmin,pmax,startup,shut_down,on_off,off)
    sol = restore_on_off(sol,on_off,on,off)
    sol[sol < 1-(1e-5)] = 0
    return sol

def solve(m,sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def local_search(m,sol,relaxed):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        if relaxed[i] == 0:
            m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    sol = m1.getAttr('X', u)
    return m1.objVal,sol

def dif(a1,a2):
    l = len(a1)
    cnt=0
    for i in range(l):
        if a1[i] != a2[i]:
            cnt+=1
    return cnt/l

def get_solutions(m, sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i] == sol[i], name=f'fix_u[{i}]')
    m1.optimize()
    sols = m1.getAttr('X', m1.getVars())
    sols = torch.tensor(sols)  # Convert to PyTorch tensor
    sols_split = torch.chunk(sols, 3)
    return sols_split




def train_il(predict, data_loader, DEVICE, optimizer=None):
    """
    This function will process a whole epoch of training or validation, depending on whether an optimizer is provided.
    """
    # infoNCE_loss_function = losses.NTXentLoss(temperature=0.07,distance=DotProductSimilarity()).to(DEVICE)
    loss_fn = torch.nn.BCELoss()
    if optimizer:
        predict.train()
    else:
        predict.eval()
    mean_loss = 0
    n_samples_processed = 0
    with torch.set_grad_enabled(optimizer is not None):
        for step, batch in enumerate(data_loader):
            batch = batch.to(DEVICE)
            embeddings = predict(batch).reshape(len(batch), -1)
            average_local = torch.from_numpy(np.array(batch.positive)).float().to(DEVICE).mean(dim=1)
            loss = loss_fn(embeddings, average_local)
            if optimizer is not None:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            mean_loss += loss.item()
            n_samples_processed += 1
    mean_loss /= n_samples_processed
    return mean_loss

from pytorch_metric_learning import losses
from pytorch_metric_learning.distances import DotProductSimilarity

def train_cl(predict, data_loader, DEVICE, optimizer=None):
    """
    This function will process a whole epoch of training or validation, depending on whether an optimizer is provided.
    """
    infoNCE_loss_function = losses.NTXentLoss(temperature=0.07,distance=DotProductSimilarity()).to(DEVICE)
    # loss_fn = torch.nn.BCELoss()
    if optimizer:
        predict.train()
    else:
        predict.eval()
    mean_loss = 0
    n_samples_processed = 0
    with torch.set_grad_enabled(optimizer is not None):
        for step, batch in enumerate(data_loader):

            batch = batch.to(DEVICE)
            embeddings = predict(batch).reshape(len(batch), -1)
            anchor_positive = torch.tensor([i for i in range(len(batch)) for j in range(len(batch.positive[i]))])
            anchor_negative = torch.tensor([i for i in range(len(batch)) for j in range(len(batch.negative[i]))])
            positive_idx = torch.arange(len(batch),len(batch)+len(anchor_positive))
            negative_idx = torch.arange(len(batch)+len(anchor_positive),len(batch)+len(anchor_positive)+len(anchor_negative))
            positive = torch.from_numpy(np.concatenate(batch.positive)).to(DEVICE)
            negative = torch.from_numpy(np.concatenate(batch.negative)).to(DEVICE)
            embeddings = torch.cat((embeddings, positive, negative),0)
            triplets = (anchor_positive.to(DEVICE), positive_idx.to(DEVICE), anchor_negative.to(DEVICE), negative_idx.to(DEVICE))

            loss = infoNCE_loss_function(embeddings, indices_tuple = triplets)
            if optimizer is not None:
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            mean_loss += loss.item()
            n_samples_processed += 1
    mean_loss /= n_samples_processed
    return mean_loss
