import copy
import torch
import torch_geometric
from torch_geometric import nn

class BipartiteGraphConvolution(nn.MessagePassing):
    """
    The bipartite graph convolution is already provided by pytorch geometric and we merely need
    to provide the exact form of the messages being passed.
    """

    def __init__(self,emb_size):
        super().__init__("add")
            
        self.feature_module_left = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size)
        )
        self.feature_module_edge = torch.nn.Sequential(
            torch.nn.Linear(1, emb_size, bias=False)
        )
        self.feature_module_right = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size, bias=False)
        )
        self.feature_module_final = torch.nn.Sequential(
            torch.nn.LayerNorm(emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
        )
        
    

    def forward(self, left_features, edge_indices, edge_features, right_features):
        output = self.propagate(
            edge_indices,
            size=(left_features.shape[0], right_features.shape[0]),
            node_features=(left_features, right_features),
            edge_features=edge_features,
        )
        return output
            
    def message(self, node_features_i, node_features_j, edge_features):
        output = self.feature_module_final(
            self.feature_module_left(node_features_i)
            + self.feature_module_edge(edge_features)
            + self.feature_module_right(node_features_j)
        )
        return output
    


class GNNPolicy(torch.nn.Module):
    def __init__(self):
        super(GNNPolicy, self).__init__()
        emb_size=64
        self.var_node = ['u','p','s']
        self.con_node = ['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
        self.node_types=['u','p','s','Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
        self.relations = ['v2c','c2v']
        self.init_sizes=[7,7,7,4,4,4,4,4,4,4]
        edge_feats=1
        self.num_relations=len(self.var_node)*len(self.con_node)
        self.vc_idx={}
        self.node_types = ['u','p','s','Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']    
        self.node_embedding = torch.nn.ModuleList()
        for i in [7,4]:
            lin = torch.nn.Sequential(
                torch.nn.LayerNorm(i),
                torch.nn.Linear(i, emb_size),
                torch.nn.ReLU(),
                torch.nn.Linear(emb_size,emb_size),
                torch.nn.ReLU()
            )
            self.node_embedding.append(lin)
        self.edge_embedding = torch.nn.LayerNorm(edge_feats)

    
        self.concv1=BipartiteGraphConvolution(emb_size)
        self.concv2=BipartiteGraphConvolution(emb_size)

        self.embv1=self.down_scale(emb_size)
        self.embv2=self.down_scale(emb_size)

        self.convc1=BipartiteGraphConvolution(emb_size)
        self.convc2=BipartiteGraphConvolution(emb_size)
        self.embc1=self.down_scale(emb_size)
        self.embc2=self.down_scale(emb_size)

        self.ln = torch.nn.LayerNorm(emb_size)


        self.output_module = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False)
        )
    def down_scale(self,emb_size):
        return torch.nn.Sequential(
            torch.nn.Linear(2 * emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
        )

    def trans_dimensions(self, g):
        data = copy.deepcopy(g)
        for v in self.var_node:
            data[v].x = self.node_embedding[0](data[v].x)
        for c in self.con_node:
            data[c].x = self.node_embedding[1](data[c].x)
        cnt=0
        for v in self.var_node:
            for c in self.con_node:
                if 'edge_attr' in data[v,'v2c',c]:
                    data[v,'v2c',c].edge_attr = self.edge_embedding(data[v,'v2c',c].edge_attr)
                    data[c,'c2v',v].edge_attr = self.edge_embedding(data[c,'c2v',v].edge_attr)
                    self.vc_idx[(v,c)]=cnt
                    self.vc_idx[(c,v)]=cnt
                else:
                    self.vc_idx[(v,c)]=-1
                    self.vc_idx[(c,v)]=-1
                cnt+=1
        return data
    def process_nodes(self, target_node, source_node, emb, conv, data, edge_type):
        for node in target_node:
            x = torch.zeros_like(data[node].x)
            for other_node in source_node:
                if self.vc_idx[(other_node, node)] != -1:
                    x += conv(
                        data[other_node].x, 
                        data[other_node, edge_type, node].edge_index, 
                        data[other_node, edge_type, node].edge_attr,
                        data[node].x
                    )
            data[node].x = emb(torch.cat([data[node].x, self.ln(x)], dim=-1))
    
    def forward(self, data):
        
        data = self.trans_dimensions(data)
        self.process_nodes(self.con_node, self.var_node, self.embc1, self.convc1, data, 'v2c')
        self.process_nodes(self.var_node, self.con_node, self.embv1, self.concv1, data, 'c2v')
        self.process_nodes(self.con_node, self.var_node, self.embc2, self.convc2, data, 'v2c')
        self.process_nodes(self.var_node, self.con_node, self.embv2, self.concv2, data, 'c2v')


        x = self.output_module(data['u'].x).sigmoid()
        return x