import os

import torch
import torch_geometric

from torch_geometric.data import Data
import numpy as np

class GraphDataset(torch_geometric.data.Dataset):
    """
    This class encodes a collection of graphs, as well as a method to load such graphs from the disk.
    It can be used in turn by the data loaders provided by pytorch geometric.
    """

    def __init__(self, path):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.files = self._read_file(path)
        self.path = path

    def len(self):
        return len(self.files)

    def _read_file(self,path):
        files = os.listdir(path)
        pt_files = [f for f in files if f.endswith('.pth')]
        return pt_files
   
    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """
        file = self.files[index]
        data = torch.load(self.path+file)

        graph = data['graph']
        
        sum=1
        for v in ['u','p','s','d','sc']:
            if 'x' in graph[v]:
                sum+=graph[v].num_nodes
            else:
                graph[v].num_nodes = 0
        for c in ['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost','state_variable']:
            if 'x' in graph[c]:
                sum+=graph[c].num_nodes
            else:
                graph[c].num_nodes = 0
        graph['obj'].x = graph['obj'].x.reshape(1,-1)
        graph.num_nodes = sum
        # graph['u'].x = torch.from_numpy(np.array(graph['u'].x)).float()
        # graph['p'].x = torch.from_numpy(np.array(graph['p'].x)).float()
        # graph['s'].x = torch.from_numpy(np.array(graph['s'].x)).float()
        
        graph.positive = data['positive']
        # print(len(graph.positive))
        graph.negative = data['negative']
        # graph.positive = torch.from_numpy(np.array(data['positive'])).float().mean(dim=0).unsqueeze(0)
        # print(graph.positive.shape)
        # graph.negative = torch.from_numpy(np.array(data['negative'])).unsqueeze(0)

        return graph
    

