from hmac import new
import sys
from turtle import pos
import gurobipy as gp
import numpy as np
from uc_class import UC
from model.tripartite_lp import GNNPolicy as Trimodel
import torch
from utilities import *
import os
import json
import copy
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
from rich import print
from multiprocessing import Pool




def local_search(m,sol,relaxed):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        if relaxed[i] == 0:
            m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.setParam('TimeLimit', 360)
    m1.setParam('Threads', 1)
    m1.setParam('MIPGap', 1e-3)
    m1.optimize()
    return m1.objVal

def reduce_redundant(neighbor,rate=0.2):
    ones_indices = np.where(neighbor == 1)[0]
    num_to_change = len(ones_indices) - int(len(neighbor)*rate)
    if num_to_change > 0:
        indices_to_change = np.random.choice(ones_indices, size=num_to_change, replace=False)
        neighbor[indices_to_change] = 0
    return neighbor

def solve(m,sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    if m1.status != 2:
        m1.computeIIS()
        for c in m1.getConstrs():
            if c.IISConstr:
                print(c.constrName)
    return m1.objVal

# def get_solutions(m, sol):
#     m1 = m.copy()
#     u = m1.getVars()[:len(sol)]
#     for i in range(len(sol)):
#         m1.addConstr(u[i] == sol[i], name=f'fix_u[{i}]')
#     m1.optimize()
#     sols = m1.getAttr('X', m1.getVars())
#     sols = torch.tensor(sols)  # Convert to PyTorch tensor
#     sols_split = torch.chunk(sols, 3)
#     return sols_split

def flip_neighbor(neighbor,change_rate=0.025):
    # num_to_change = len(neighbor)//40
    num_to_change = int(len(neighbor)*change_rate)
    indices_to_change = np.random.choice(len(neighbor), size=num_to_change, replace=False)
    neighbor[indices_to_change] = np.bitwise_xor(neighbor[indices_to_change], 1)
    return neighbor


def process(G):
    file,json_path,data_path,uc = G
    with open(os.path.join(json_path, file),'r') as f:
        data = json.load(f)
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    best_obj = data['obj']
    m3 = uc.get_3bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    m1 = uc.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    # negative_datasets = data['negative_datasets']
    positive_datasets = data['positive_datasets']

    sol_list = data['sol_list']
    opt_sol = positive_datasets[0]
    def gen_graph_by_sol(sol,graph1,graph3):
        # f=0
        # for c in m.getConstrs():
        #     if 'fix' in c.constrName:
        #         print(0)
        #         f=1
        #         break
        # if f==0: print('ok0')
        best_obj = solve(m3,opt_sol)
        # for c in m.getConstrs():
        #     if 'fix' in c.constrName:
        #         print(1)
        #         break
        cur_obj = solve(m3,sol)
        # for c in m.getConstrs():
        #     if 'fix' in c.constrName:
        #         print(2)
        #         break
        positive_neighbors=[]
        for positive in positive_datasets:
            
            neighbor = np.bitwise_xor(sol,positive)
            if np.count_nonzero(neighbor)>len(neighbor)//5:
                neighbor = reduce_redundant(neighbor,0.2)
            
            new_obj = local_search(m3,sol,neighbor)
            # for c in m.getConstrs():
            #     if 'fix' in c.constrName:
            #         print(3)
            #     break
            if cur_obj-new_obj>0.6*(cur_obj-best_obj):
                positive_neighbors.append(neighbor.copy())

        negative_num = len(positive_neighbors)*9
        negative_neighbors = []
        max_iter=20
        while max_iter>0 and len(negative_neighbors)<negative_num:
            change_rate=0.05
            for neighbor in positive_neighbors:
                neighbor = flip_neighbor(neighbor,change_rate)
                new_obj = local_search(m3,sol,neighbor)
                if cur_obj-new_obj<0.05*(cur_obj-best_obj):
                    negative_neighbors.append(neighbor.copy())
            change_rate=min(0.5,0.05)

            max_iter-=1
        negative_num = len(negative_neighbors)
        if negative_num<=1:
            return
        positive_num = negative_num//9
        positive_neighbors = positive_neighbors[:positive_num]
        torch.save({
            'graph': graph1,
            'positive': positive_neighbors,
            'negative': negative_neighbors,
        },os.path.join(data_path,'1bin',file[:-5]+f'_{idx}.pth'))
        torch.save({
            'graph': graph3,
            'positive': positive_neighbors,
            'negative': negative_neighbors,
        },os.path.join(data_path,'3bin',file[:-5]+f'_{idx}.pth'))



    for idx,sol in enumerate(sol_list):
        sol = np.round(sol).astype(int)

        graph1 = get_Tripartite_graph_lp_with_sol(m1,sol)
        graph3 = get_Tripartite_graph_lp_with_sol(m3,sol)
        gen_graph_by_sol(sol,graph1,graph3)


#主函数
def main():
    dirs=['train','valid','test']
    CORE_NUM = 60
    uc_path = '/home/peilun/predict_heuristicFix_loopEnhance/UC_AF/80_c11_based_8_std.mod'
    uc = UC(uc_path)
    
    for dir in dirs:
        # if dir == 'train':
        #     continue
        json_path = os.path.join('datasets/80_c11_based_8_std/total_json',dir)
        data_path = os.path.join('datasets/80_c11_based_8_std/small_range_local_search_tripartite',dir)
        
        os.makedirs(data_path+'/1bin',exist_ok=True)
        os.makedirs(data_path+'/3bin',exist_ok=True)

        json_files = os.listdir(json_path)
        move = [(file,json_path,data_path,uc) for file in json_files if file.endswith('.json')]

        with Progress(
            "[progress.description]{task.description}({task.completed}/{task.total})",
            BarColumn(),
            "[progress.percentage]{task.percentage:>3.2f}%",
            TimeElapsedColumn(),
            '<',
            TimeRemainingColumn(),
        ) as progress:
            task_id = progress.add_task(f"[cyan]Processing {dir} files...", total=len(move))

            with Pool(processes=CORE_NUM) as pool:
                for _ in pool.imap_unordered(process, move):

                    progress.update(task_id, advance=1)


if __name__ == "__main__":
    main()
    # dirs=['train','valid','test']
    # for dir in dirs:
    #     json_path = os.path.join('datasets/80_c11_based_8_std/total_json',dir)

    #     json_files = os.listdir(json_path)
    #     sol_nums = []
    #     for file in json_files:
    #         with open(os.path.join(json_path, file),'r') as f:
    #             data = json.load(f)
    #         sol_list = data['sol_list']
            

    #         sol_nums.append(len(sol_list))
    #     print(np.mean(sol_nums))