import sys
import gurobipy as gp
import numpy as np
from sympy import im
from uc_class import UC
from model.tripartite_lp import GNNPolicy as Trimodel
from gurobipy import GRB # type: ignore
import torch
from utilities import *
import os
import json
import copy
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
# from gurobipy import GRB
from rich import print
from multiprocessing import Pool

dirs=['train','valid','test']

def mycallback(model, where):
    
    if where == GRB.Callback.MIPSOL:
        obj = model.cbGet(GRB.Callback.MIPSOL_OBJ)
        sol = model.cbGetSolution(model._u)
        model._objs.append(obj)
        model._sols.append(sol)
    
def local_search(m,sol,relaxed):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        if relaxed[i] == 0:
            m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def get_positive(m,num_positive):
    m.setParam('OutputFlag', 0)
    m.setParam('Threads', 1)
    m.setParam('MIPGap', 1e-7)
    m.setParam('PoolSearchMode', 2)
    m.setParam('PoolSolutions', num_positive+1)
    # m.setParam('MIPFocus', 2)
    m.setParam('TimeLimit', 60)
    mvars = m.getVars()
    u=[mvars[i] for i in range(len(mvars)) if 'u' in mvars[i].VarName]
    m.optimize(mycallback)
    objs = []
    if m.SolCount > 0:
        positives = []
        for sn in range(m.SolCount):
            m.setParam('SolutionNumber', sn)
            sol = np.round(m.getAttr("Xn", u)).astype(int)
            positives.append(sol)
            objs.append(m.PoolObjVal)
        positives = np.array(positives)
        return positives,np.mean(objs),m.objVal
    return np.array([]),0,0

def get_negative(m,num_negative,opt_neighbor,opt_obj):
    m.setParam('OutputFlag',0)
    m.setParam('MIPGap', 1e-2)
    m.setParam('Threads', 1)
    m.setParam('PoolSearchMode', 2)
    m.setParam('PoolSolutions', num_negative)
    m.setParam('TimeLimit', 4)
    m.optimize()

    if m.SolCount > 0:
        negatives = []
        for sn in range(m.SolCount):
            m.setParam('SolutionNumber',sn)
            mvars=m.getVars()
            u=[mvars[i] for i in range(len(mvars)) if 'u' in mvars[i].VarName]
            sol = np.round(m.getAttr("Xn", u)).astype(int)
            negatives.append(sol)
        negatives=np.array(negatives)
        return negatives
    return np.array([])

def solve(m,sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def process(G):
    file,json_path,new_json_path,uc = G
    with open(os.path.join(json_path, file),'r') as f:
        data = json.load(f)
    pmax = uc.ThPimax
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    m = uc.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    mvars = m.getVars()
    u=[mvars[i] for i in range(len(mvars)) if 'u' in mvars[i].VarName]
    m._u = u
    m._objs=[]
    m._sols=[]


    positive_datasets,mean_obj,best_obj = get_positive(m,10)
    negative_datasets = get_negative(m,10*9,positive_datasets[0],best_obj)

    sol_list = []
    obj_list = []
    for obj,sol in zip(m._objs,m._sols):
        if (obj - mean_obj)/obj > 1e-5:
            sol_list.append(sol)
            obj_list.append(obj)
    

    data['sol_list'] = sol_list
    data['obj_list'] = obj_list
    data['positive_datasets'] = positive_datasets.tolist()
    data['negative_datasets'] = negative_datasets.tolist()
    with open(os.path.join(new_json_path, file),'w') as f:
        json.dump(data,f)

#主函数
def main():
    # num_perturb = 5#一个MILP生成多少个例子
    CORE_NUM = 50
    instances = ['80_c11_based_8_std']
    for ins in instances:
        uc_path = f'/home/peilun/predict_heuristicFix_loopEnhance/UC_AF/{ins}.mod'
        uc = UC(uc_path)
        for dir in dirs:
            # if dir == 'train':
            #     continue

            json_path = os.path.join(f'datasets/{ins}/json',dir)
            new_json_path = os.path.join(f'datasets/{ins}/total_json',dir)
            os.makedirs(new_json_path,exist_ok=True)

            json_files = os.listdir(json_path)
            move = [(file,json_path,new_json_path,uc) for file in json_files if file.endswith('.json')]
            
            with Progress(
                "[progress.description]{task.description}({task.completed}/{task.total})",
                BarColumn(),
                "[progress.percentage]{task.percentage:>3.2f}%",
                TimeElapsedColumn(),
                '<',
                TimeRemainingColumn(),
            ) as progress:
                task_id = progress.add_task(f"[cyan]Processing {ins} {dir} files...", total=len(move))

                with Pool(processes=CORE_NUM) as pool:
                    for _ in pool.imap_unordered(process, move):

                        progress.update(task_id, advance=1)


if __name__ == "__main__":
    main()