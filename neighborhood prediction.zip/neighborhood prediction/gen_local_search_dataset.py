import sys
import gurobipy as gp
import numpy as np
from uc_class import UC
import torch
from utilities import *
import os
import json
import copy
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
from rich import print
from multiprocessing import Pool




def local_search(m,sol,relaxed):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        if relaxed[i] == 0:
            m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def reduce_redundant(neighbor):
    ones_indices = np.where(neighbor == 1)[0]
    num_to_change = len(ones_indices) - int(len(neighbor)*0.2)
    if num_to_change > 0:
        indices_to_change = np.random.choice(ones_indices, size=num_to_change, replace=False)
        neighbor[indices_to_change] = 0
    return neighbor

def solve(m,sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def get_solutions(m, sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i] == sol[i], name=f'fix_u[{i}]')
    m1.optimize()
    sols = m1.getAttr('X', m1.getVars())
    sols = torch.tensor(sols)  # Convert to PyTorch tensor
    sols_split = torch.chunk(sols, 3)
    return sols_split

def cal_sol_num(sol,un,nums):
    sol=np.array(sol)
    sol = sol.reshape(-1,24)
    T=24
    ct=0
    ans=np.array([[0]*T for _ in range(un)])
    for i in range(un):
        for k in range(nums[i]):
            for t in range(T):
                if sol[ct+k][t]==1:
                    ans[i][t]+=1
        ct+=nums[i]
    return ans

def process(G):
    file,json_path,data_path,uc = G
    with open(os.path.join(json_path, file),'r') as f:
        data = json.load(f)
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    best_obj = data['obj']
    nums = uc.nums
    un = len(nums)
    m = uc.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    m.setParam('Threads', 1)
    # negative_datasets = data['negative_datasets']
    positive_datasets = data['positive_datasets']
    if len(positive_datasets)<2:
        return
    sol_list = data['sol_list']
    def gen_graph_by_sol(sol):
        cur_obj = solve(m,sol)
        num_sol = cal_sol_num(sol,un,nums)
        positive_datas=[]
        for positive in positive_datasets:
            num_posi = cal_sol_num(positive,un,nums)
            positive_datas.append(np.abs(num_sol-num_posi).reshape(-1))
            # neighbor = np.bitwise_xor(sol,positive)
            # neighbor = reduce_redundant(neighbor)
            # positive_datas.append(neighbor.copy())
        # times = len(positive_datasets)//len(negative_datasets)
        # res = len(positive_datasets)%len(negative_datasets)
        # negative_datas = []
        # for i,negative in enumerate(negative_datasets):
        #     if i<res:
        #         t=times+1
        #     else:
        #         t=times
        #     for _ in range(t):
        #         neighbor = np.bitwise_xor(sol,negative)
        #         neighbor = reduce_redundant(neighbor)
        #         num_to_change = len(neighbor)//40
        #         indices_to_change = np.random.choice(len(neighbor), size=num_to_change, replace=False)
        #         neighbor[indices_to_change] = np.bitwise_xor(neighbor[indices_to_change], 1)
        #         new_obj = local_search(m,sol,neighbor)
        #         cnt=0
        #         while (cur_obj-new_obj)/max(1e-5,(cur_obj-best_obj))>0.5:
        #             num_to_change = min(num_to_change*2,len(neighbor)//10)
        #             indices_to_change = np.random.choice(len(neighbor), size=num_to_change, replace=False)
        #             neighbor[indices_to_change] = np.bitwise_xor(neighbor[indices_to_change], 1)
        #             new_obj = local_search(m,sol,neighbor)
        #             cnt+=1
        #             if cnt>=10:
        #                 return
        #         negative_datas.append(neighbor.copy())
        graph = copy.deepcopy(graph_bk)
        u_sol,p_sol,s_sol = get_solutions(m,sol)
        sol_dict = {'u': u_sol, 'p': p_sol, 's': s_sol}  # u_sol, p_sol, s_sol 是对应的解

        for v in ['u','p','s']:
            graph[v].x = torch.cat((graph[v].x, sol_dict[v].reshape(-1,1)), dim=1)
            # graph[v].x[..., -1] = sol_dict[v].reshape(-1)
        # print(os.path.join(data_path,file[:-5]+f'_{idx}_{num}.pth'))
        torch.save({
            'graph': graph,
            'nums': nums,
            'positive': positive_datas,
            # 'negative': negative_datas,
        },os.path.join(data_path,file[:-5]+f'_{idx}.pth'))


    

    graph_bk = get_Tripartite_graph_lp(m)
    for idx,sol in enumerate(sol_list):
        sol = np.round(sol).astype(int)
        gen_graph_by_sol(sol)

#主函数
def main():
    # instance = '1080_c30_based_8_std'
    instance = '80_c11_based_8_std'
    dirs=['train','valid','test']
    CORE_NUM = 60
    uc_path = f'UC_AF/{instance}.mod'
    uc = UC(uc_path)
    
    for dir in dirs:
        json_path = os.path.join(f'datasets/{instance}/total_json',dir)
        data_path = os.path.join(f'datasets/{instance}/num_dif_local_search',dir)
        # data_path = os.path.join(f'datasets/{instance}/small_range_local_search_tripartite',dir)
        os.makedirs(data_path,exist_ok=True)

        json_files = os.listdir(json_path)
        move = [(file,json_path,data_path,uc) for file in json_files if file.endswith('.json')]

        with Progress(
            "[progress.description]{task.description}({task.completed}/{task.total})",
            BarColumn(),
            "[progress.percentage]{task.percentage:>3.2f}%",
            TimeElapsedColumn(),
            '<',
            TimeRemainingColumn(),
        ) as progress:
            task_id = progress.add_task(f"[cyan]Processing {dir} files...", total=len(move))

            with Pool(processes=CORE_NUM) as pool:
                for _ in pool.imap_unordered(process, move):

                    progress.update(task_id, advance=1)


if __name__ == "__main__":
    main()