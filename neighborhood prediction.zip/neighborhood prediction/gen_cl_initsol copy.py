from hmac import new
import sys
from turtle import pos
import gurobipy as gp
import numpy as np
from uc_class import UC
from model.tripartite_lp import GNNPolicy as Trimodel
import torch
from utilities import *
import os
import json
import copy
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
from rich import print
from multiprocessing import Pool





def process(G):
    file,json_path,data_path,uc = G
    with open(os.path.join(json_path, file),'r') as f:
        data = json.load(f)
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    mr = uc.get_3bin_model_1bin_ramp(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    ms = uc.get_3bin_model_1bin_startupcost(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    # m1 = uc.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    # m1 = uc.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)


    negative_datasets = data['negative_datasets']
    positive_datasets = data['positive_datasets']

    trir = get_Tripartite_graph_lp(mr)
    tris = get_Tripartite_graph_lp(ms)
    torch.save({
        'graph': trir,
        'positive': positive_datasets,
        'negative': negative_datasets,
    },os.path.join(data_path,'ramp',file[:-5]+f'.pt'))
    torch.save({
        'graph': tris,
        'positive': positive_datasets,
        'negative': negative_datasets,
    },os.path.join(data_path,'startup',file[:-5]+f'.pt'))




#主函数
def main():
    instances = ['80_c11_based_8_std']

    for ins in instances:
        
        dirs=['train','valid','test']
        CORE_NUM = 60
        uc_path = f'/home/peilun/predict_heuristicFix_loopEnhance/UC_AF/{ins}.mod'
        uc = UC(uc_path)
        
        for dir in dirs:
            # if dir == 'train':
            #     continue
            json_path = os.path.join(f'datasets/{ins}/total_json',dir)
            data_path = os.path.join(f'datasets/{ins}/initsol',dir)
            
            os.makedirs(data_path+'/ramp',exist_ok=True)
            os.makedirs(data_path+'/startup',exist_ok=True)

            json_files = os.listdir(json_path)
            move = [(file,json_path,data_path,uc) for file in json_files if file.endswith('.json')]

            with Progress(
                "[progress.description]{task.description}({task.completed}/{task.total})",
                BarColumn(),
                "[progress.percentage]{task.percentage:>3.2f}%",
                TimeElapsedColumn(),
                '<',
                TimeRemainingColumn(),
            ) as progress:
                task_id = progress.add_task(f"[cyan]Processing {dir} files...", total=len(move))

                with Pool(processes=CORE_NUM) as pool:
                    for _ in pool.imap_unordered(process, move):

                        progress.update(task_id, advance=1)


if __name__ == "__main__":
    main()