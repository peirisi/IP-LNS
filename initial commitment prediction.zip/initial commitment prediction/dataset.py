import os

import torch
import torch_geometric


class BipartiteNodeData(torch_geometric.data.Data):
    """
    This class encode a node bipartite graph observation as returned by the `ecole.observation.NodeBipartite`
    observation function in a format understood by the pytorch geometric data handlers.
    """

    def __init__(
            self,
            constraint_features,
            edge_indices,
            edge_features,
            variable_features,

    ):
        super().__init__()
        self.constraint_features = constraint_features
        self.edge_index = edge_indices
        self.edge_attr = edge_features
        self.variable_features = variable_features



    def __inc__(self, key, value, store):
        """
        We overload the pytorch geometric method that tells how to increment indices when concatenating graphs
        for those entries (edge index, candidates) for which this is not obvious.
        """
        if key == "edge_index":
            return torch.tensor(
                [[self.constraint_features.size(0)], [self.variable_features.size(0)]]
            )
        else:
            return super().__inc__(key, value)

class GraphDataset(torch_geometric.data.Dataset):
    """
    This class encodes a collection of graphs, as well as a method to load such graphs from the disk.
    It can be used in turn by the data loaders provided by pytorch geometric.
    """

    def __init__(self, path):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.files = self._read_file(path)
        self.path = path

    def len(self):
        return len(self.files)

    def _read_file(self,path):
        files = os.listdir(path)
        pt_files = [f for f in files if f.endswith('.pt')]
        return pt_files
   
    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """
        file = self.files[index]
        data = torch.load(self.path+file)

        weighted_sol = data['weighted_sol']
        edge_indices = data['A_indices']
        edge_features = data['A_values']
        v_nodes = data['v_nodes'] 
        c_nodes = data['c_nodes']
        b_vars = data['b_vars']
        # constraint_features = c_nodes
         
        v_nodes=torch.nan_to_num(v_nodes)

        # variable_features = v_nodes
        edge_features=edge_features.float()

        graph = BipartiteNodeData(
            c_nodes.float(),
            edge_indices.long(),
            edge_features.float(),
            v_nodes.float(),
        )
        
        
        
        # We must tell pytorch geometric how many nodes there are, for indexing purposes
        graph.num_nodes = c_nodes.shape[0] + v_nodes.shape[0]

        for i in weighted_sol:
            if i<0:
                i=0
            elif i>1:
                i=1
        
        graph.weighted_sol = weighted_sol.clone().detach().reshape(-1)
        graph.opt_sol = torch.round(data['opt_sol'])

        graph.b_vars = b_vars.reshape(-1)

        return graph