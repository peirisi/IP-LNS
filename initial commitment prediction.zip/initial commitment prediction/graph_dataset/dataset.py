import os
import torch
import torch_geometric
import json
import numpy as np
import sys
# sys.path[0]+='/..'
# print(sys.path)
from uc_class import UC


def get_fea(m):
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = m.getA().tocoo()
    values = coo.data
    indices = np.vstack((coo.row, coo.col))
    i = torch.LongTensor(indices)
    v = torch.FloatTensor(values)
    A = torch.sparse_coo_tensor(i, v, coo.shape)
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1)
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1)
    return A._indices(), A._values().unsqueeze(1), v_nodes.float(), c_nodes.float(), b_vars



class BipartiteNodeData(torch_geometric.data.Data):
    """
    This class encode a node bipartite graph observation as returned by the `ecole.observation.NodeBipartite`
    observation function in a format understood by the pytorch geometric data handlers.
    """

    def __init__(
            self,
            constraint_features,
            edge_indices,
            edge_features,
            variable_features,

    ):
        super().__init__()
        self.constraint_features = constraint_features
        self.edge_index = edge_indices
        self.edge_attr = edge_features
        self.variable_features = variable_features



    def __inc__(self, key, value, store):
        """
        We overload the pytorch geometric method that tells how to increment indices when concatenating graphs
        for those entries (edge index, candidates) for which this is not obvious.
        """
        if key == "edge_index":
            return torch.tensor(
                [[self.constraint_features.size(0)], [self.variable_features.size(0)]]
            )
        else:
            return super().__inc__(key, value)

class GraphDataset(torch_geometric.data.Dataset):
    """
    This class encodes a collection of graphs, as well as a method to load such graphs from the disk.
    It can be used in turn by the data loaders provided by pytorch geometric.
    """

    def __init__(self, path):
        super().__init__(root=None, transform=None, pre_transform=None)
        self.files = self._read_file(path)
        self.path = path

    def len(self):
        return len(self.files)

    def _read_file(self,path):
        files = os.listdir(path)
        json_files = [f for f in files if f.endswith('.json')]
        return json_files
   
    def get(self, index):
        """
        This method loads a node bipartite graph observation as saved on the disk during data collection.
        """
        file = self.files[index]
        # print(sys.path)
        with open(self.path+file, "r") as f:
            data = json.load(f)
        
        weighted_sol = data['weighted_sol']   
        opt_sol = data['opt_sol']
        Dt = data['Dt']
        Spin = data['Spin']
        u0 = data['u0']
        p0 = data['p0']
        on_off = data['on_off']
        instance = data['instance']
        file = '../UC_AF/'+instance+'.mod'
        # print(sys.path)
        uc = UC(file)
        m = uc.get_3bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
        A_indices, A_values, v_nodes, c_nodes, b_vars=get_fea(m)         
        v_nodes=torch.nan_to_num(v_nodes)

        graph = BipartiteNodeData(
            c_nodes.float(),
            A_indices,
            A_values,
            v_nodes.float(),
        ) 
        # We must tell pytorch geometric how many nodes there are, for indexing purposes
        graph.num_nodes = c_nodes.shape[0] + v_nodes.shape[0]


        graph.weighted_sol = torch.tensor(weighted_sol,dtype=torch.float32).clone().detach().reshape(-1)
        graph.opt_sol = torch.tensor(opt_sol,dtype=torch.float32).clone().detach().reshape(-1)
        graph.b_vars = b_vars.reshape(-1)
        graph.obj = data['obj']
    

        return graph