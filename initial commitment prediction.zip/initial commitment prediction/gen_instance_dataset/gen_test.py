import sys
sys.path[0]+='/..'
import gurobipy as gp
import numpy as np
from uc_class import UC
import torch
from utilities import *
import os

from concurrent.futures import ThreadPoolExecutor
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn

from rich import print
from multiprocessing import Pool


# name = '50_0_1_w'
name = 'c30_1080_based_8_std'
# name = '5_std'

# name = '10_std'
# name = '20_0_1_w'
file = 'UC_AF/'+name+'.mod'
Dt=np.loadtxt('deman/pd.csv',delimiter=',',encoding='utf-8-sig')
b3=UC(file)
sys_up=sum(b3.ThPimax)*0.8
sys_low=sys_up*0.4

pd=(Dt-Dt.min())/(Dt.max()-Dt.min())*0.85*(sys_up-sys_low)+sys_low*1.05

TLE=20
CORE_NUM=1

u0_save=np.load(f'instances/fixed/{name}/u0_save.npy')
p0_save=np.load(f'instances/fixed/{name}/p0_save.npy')
onoff_save=np.load(f'instances/fixed/{name}/onoff_save.npy')

#修复float精度问题导致发电量小于下界
# pmin = b3.ThPimin

# for u0,p0 in zip(u0_save,p0_save):
#     for i in range(len(pmin)):
#         if u0[i]==1 and p0[i]<pmin[i]:
#             print('error')
#             p0[i]=pmin[i]
# np.save(f'instances/fixed/{name}/p0_save',p0_save)


def gen_by_3bin(G):
    # with gp.Env() as env, gp.Model(env=env) as m:
        cur,seed,dt,u0,p0,onoff = G
        # print(f"in{cur}_{seed}")
        # path='null'
        # if cur % 10 == 7:
        path='test'
        np.random.seed(seed)

        # Dt=np.empty(len(dt))
        # for i in range(len(dt)):
        #     Dt[i]=max(sys_low,min(sys_up,np.random.uniform(dt[i]*0.995,dt[i]*1.005)))
        # Dt*=np.random.uniform(0.99,1.01)
        Dt=dt
        Spin = Dt*0.1
        
        m=b3.get_3bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=onoff,Ui0=u0,Pi0=p0)
        # m1=b3.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=onoff,Ui0=u0,Pi0=p0)
        # N=b3.NumThermal
        # T=b3.HorizonLen

        m.setParam("OutputFlag", 0)
        m.setParam("MIPGap", 1e-3)
        m.Params.Threads = 1
        m.Params.TimeLimit = TLE
        m.Params.PoolSolutions = 10
        m.Params.PoolSearchMode = 2
        m.optimize()

        print(cur,seed,m.Status)
        if m.Status==2 or m.Status==9:
            print(f'datasets/{name}/3bin/test/{cur}_{seed}.lp')            
            if path=='test':
                m.write(f'datasets/{name}/3bin/test/{cur}_{seed}.lp')
                # m1.write(f'datasets/{name}/1bin/test/{cur}_{seed}.lp')
            return True
        return False


def gen(day):
    #筛选尾号7
    move = [(i, 0, pd[i], u0_save[i], p0_save[i], onoff_save[i]) for i in range(day)]
    # move = [(i, j, pd[i], u0_save[i], p0_save[i], onoff_save[i]) for i in range(7, day, 10) for j in range(5)]
    cnt=0
    # 创建进度条对象
    with Progress(
        "[progress.description]{task.description}({task.completed}/{task.total})",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.2f}%",
        TimeElapsedColumn(),
        '<',
        TimeRemainingColumn(),
    ) as progress:
        # 创建 ThreadPoolExecutor，使用它来并发执行任务
        with Pool(processes=CORE_NUM) as pool:
            for _ in progress.track(pool.imap(gen_by_3bin, move), total=len(move)):
                if _==False:
                    cnt+=1
                print(f'有{cnt}个失败')





# if not os.path.isdir(f'newdatasets'):
# os.makedirs(f'datasets/{name}/1bin/', exist_ok=True)
os.makedirs(f'datasets/{name}/3bin/test', exist_ok=True)

# for path0 in [name,name+'_opt']:
#     if not os.path.isdir(f'datasets/{path0}'):
#         os.mkdir(f'datasets/{path0}')

# for path0 in [name,name+'_opt']:
#     for path1 in ['3bin','1bin']:
#         if not os.path.isdir(f'datasets/{path0}/{path1}'):
#             os.mkdir(f'datasets/{path0}/{path1}')
#         for path2 in ['train','valid','test']:
#             if not os.path.isdir(f'datasets/{path0}/{path1}/{path2}'):
#                 os.mkdir(f'datasets/{path0}/{path1}/{path2}')



# gen_by_3bin((0,0,pd[0],u0_save[0],p0_save[0],onoff_save[0]))
# gen_by_3bin((0,0,pd[0],u0_save[0],p0_save[0],onoff_save[0]))
# gen_by_3bin((0,0,pd[0],u0_save[0],p0_save[0],onoff_save[0]))
# gen_by_3bin((0,0,pd[0],u0_save[0],p0_save[0],onoff_save[0]))
# gen_by_3bin((0,0,pd[0],u0_save[0],p0_save[0],onoff_save[0]))

gen(365)