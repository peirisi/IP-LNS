import gurobipy as gp
import numpy as np
import os
import sys
sys.path[0]+='/..'

from uc_class import UC
import torch
from utilities import *
import json

from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
import concurrent.futures
from torch_geometric.data import HeteroData
import collections


instance = '80_c11_based_8_std'
# instance = '60_c11_based_8_std'
# instance = '5_std'
# instance = '1080_c30_based_8_std'
file = f'UC_AF/{instance}.mod'
uc = UC(file)
json_path = f'datasets/{instance}/json'
#获取json_path下的路径名
dirs = os.listdir(json_path)

def get_graph(m):
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = m.getA().tocoo()
    # values = coo.data
    # indices = np.vstack((coo.row, coo.col))
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)

    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1).float()
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1).float()

    cons=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']

    graph = HeteroData()

    n=len(mvars)
    T=24
    N=int(sum(b_vars)/T)


    if N*T == n/3:
        graph['u'].x = v_nodes[:N*T]
        graph['p'].x = v_nodes[N*T:2*N*T]
        graph['s'].x = v_nodes[2*N*T:3*N*T]

        r = 0
        idx=0
        for l, c in enumerate(constrs):
            if cons[idx] in c.ConstrName and l != len(constrs) - 1:
                continue
            if l == len(constrs) - 1:
                l+=1
            graph[cons[idx]].x = c_nodes[r:l]


            uindice = []
            pindice = []
            sindice = []
            uvalues = []
            pvalues = []
            svalues = []

            for constr, variable, value in zip(coo.row, coo.col, coo.data):
                if r <= constr < l:
                    if variable < N*T:
                        uindice.append((variable, constr-r))
                        uvalues.append(value)
                    elif N*T <= variable < 2*N*T:
                        pindice.append((variable-N*T, constr-r))
                        pvalues.append(value)
                    elif variable >= 2*N*T:
                        sindice.append((variable-2*N*T, constr-r))
                        svalues.append(value)

            uindice = np.array(uindice).T
            pindice = np.array(pindice).T
            sindice = np.array(sindice).T
            uvalues = torch.tensor(uvalues, dtype=torch.float32).reshape(-1,1)
            pvalues = torch.tensor(pvalues, dtype=torch.float32).reshape(-1,1)
            svalues = torch.tensor(svalues, dtype=torch.float32).reshape(-1,1)

            if uindice.size:
                graph['u','v2c',cons[idx]].edge_index = torch.from_numpy(uindice)
                graph['u','v2c',cons[idx]].edge_attr = uvalues
                graph[cons[idx],'c2v','u'].edge_index = torch.from_numpy(uindice[[1,0]])
                graph[cons[idx],'c2v','u'].edge_attr = uvalues
            if pindice.size:
                graph['p','v2c',cons[idx]].edge_index = torch.from_numpy(pindice)
                graph['p','v2c',cons[idx]].edge_attr = pvalues
                graph[cons[idx],'c2v','p'].edge_index = torch.from_numpy(pindice[[1,0]])
                graph[cons[idx],'c2v','p'].edge_attr = pvalues
            if sindice.size:                
                graph['s','v2c',cons[idx]].edge_index = torch.from_numpy(sindice)
                graph['s','v2c',cons[idx]].edge_attr = svalues
                graph[cons[idx],'c2v','s'].edge_index = torch.from_numpy(sindice[[1,0]])
                graph[cons[idx],'c2v','s'].edge_attr = svalues
            r = l
            idx += 1
        graph
        return graph


from torch_geometric.data import HeteroData

import torch
def get_norm(ori_tensor):
    ori_tensor = ori_tensor.reshape(-1,1)
    norm = torch.norm(ori_tensor, keepdim=True)
    norm_tensor = (ori_tensor/(norm+1e-6))
    return torch.cat((ori_tensor, norm_tensor), dim=1)


def get_Tripartite_graph(m):
    r=m.relax()
    r.setParam('OutputFlag', 0)
    r.optimize()
    rvars=r.getVars()
    # constraints=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
    # variables=['u','p','s']
    variables=[]
    constraints=[]
    mvars = m.getVars()
    constrs = m.getConstrs()
    for v in mvars:
        vname = v.VarName.split('[')[0]
        if vname not in variables:
            variables.append(vname)
    for c in constrs:
        cname = c.ConstrName.split('[')[0]
        cname = cname.rstrip('0123456789')
        if cname not in constraints:
            constraints.append(cname)
    A = m.getA()
    rows, cols = A.shape
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = A.tocoo()
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v6 = torch.tensor([v.x for v in rvars]).reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5,v6),1).float()
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1).float()

    tot=int(cols/len(variables))
    col_slides=collections.defaultdict(int)
    for v in variables:
        col_slides[v]=int(tot)
    row_slides=[]
    graph = HeteroData()

    row_slides = collections.defaultdict(int)
    cons = m.getConstrs()
    t=0
    coc=0
    for c in cons:
        name=constraints[t]
        while name not in c.ConstrName:
            t+=1
            name=constraints[t]
        if t>=len(constraints):
            break
        row_slides[name]+=1
    lastv=0
    for v in variables:
        graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
        lastv+=col_slides[v]
    lastc=0
    for c in constraints:
        graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
        lastc+=row_slides[c]
    lastr=0
    for c in constraints:
        lastc=0
        for v in variables:
            mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
            lastc+=col_slides[v]
            values = mtx.data
            if len(values)==0:
                continue
            row_indices = mtx.row
            col_indices = mtx.col
            indices = np.vstack((row_indices, col_indices))
            graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
            graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
        lastr+=row_slides[c]

    
    #o节点
    graph['obj'].x = torch.tensor([r.objVal]).reshape(-1,1)
    con_indice=[]
    con_attr=[]
    idx=0
    t=0
    for c in r.getConstrs():
        name=constraints[t]
        while name not in c.ConstrName:
            if 'edge_attr' in graph['obj','o2c',name]:
                graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
                graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
                graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
            t+=1
            name=constraints[t]
            idx=0
            con_indice=[]
            con_attr=[]
        if t>=len(constraints):
            break
        
        if c.Slack < 1e-6:
            con_indice.append((0,idx))
            con_attr.append(c.RHS)
        idx+=1
    graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
    graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
    graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
    #加入ov边
    for i,v in enumerate(['u','p','s']):
        graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1,tot, dtype=torch.int64), torch.arange(0,tot).unsqueeze(0)), 0)
        graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, tot).unsqueeze(0), torch.zeros(1, tot, dtype=torch.int64)), 0)
        graph['obj','o2v',v].edge_attr = get_norm(v0[tot*i:tot*(i+1)])

    return graph




print('start')
file_dir='tripartite_lpsolve'

with Progress(
        "[progress.description]{task.description}({task.completed}/{task.total})",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.2f}%",
        TimeElapsedColumn(),
        '<',
        TimeRemainingColumn(),
) as progress:
    for dir in dirs:
        #在进度条中加入dir
        # progress.console.print(f"[bold cyan]Processing {dir} files...")
        os.makedirs(f'datasets/{instance}/1bin/{file_dir}/{dir}/', exist_ok=True)
        os.makedirs(f'datasets/{instance}/3bin_1bin_ramp/{file_dir}/{dir}/', exist_ok=True)
        os.makedirs(f'datasets/{instance}/3bin_1bin_startupcost/{file_dir}/{dir}/', exist_ok=True)
        # os.makedirs(f'datasets/{instance}/1bin/{file_dir}/lp/{dir}', exist_ok=True)

        path = os.path.join(json_path,dir)
        json_files = os.listdir(path)
        
        for json_file in progress.track(json_files,total=len(json_files)):
            # print(os.path.join(path,json_file))
            with open(os.path.join(path,json_file),'r') as f:
                data = json.load(f)
            weighted_sol = torch.tensor(data['weighted_sol'],dtype=torch.float32).reshape(-1)
            opt_sol = torch.tensor(data['opt_sol'],dtype=torch.float32).reshape(-1)
            Dt = data['Dt']
            Spin = data['Spin']
            u0 = data['u0']
            p0 = data['p0']
            on_off = data['on_off']
            m3r = uc.get_3bin_model_1bin_ramp(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
            m3s = uc.get_3bin_model_1bin_startupcost(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
            # m1 = uc.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
            
          

            # graph1=get_Tripartite_graph(m1)
            graph3r=get_Tripartite_graph(m3r)
            graph3s=get_Tripartite_graph(m3s)
   
            # torch.save({
            #             'graph':graph1,
            #             'weighted_sol':weighted_sol,
            #             'opt_sol':opt_sol,
            #             'obj':data['obj'],
            #         },f'datasets/{instance}/1bin/{file_dir}/{dir}/{json_file[:-5]}.pt')
            torch.save({
                        'graph':graph3r,
                        'weighted_sol':weighted_sol,
                        'opt_sol':opt_sol,
                        'obj':data['obj'],
                    },f'datasets/{instance}/3bin_1bin_ramp/{file_dir}/{dir}/{json_file[:-5]}.pt')
            torch.save({
                        'graph':graph3s,
                        'weighted_sol':weighted_sol,
                        'opt_sol':opt_sol,
                        'obj':data['obj'],
                    },f'datasets/{instance}/3bin_1bin_startupcost/{file_dir}/{dir}/{json_file[:-5]}.pt')
            