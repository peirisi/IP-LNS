# from hmac import new
import sys
sys.path[0]+='/..'

import gurobipy as gp
import numpy as np
from uc_class import UC
import torch
from utilities import *
import os
import json
import copy
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
from rich import print
from multiprocessing import Pool




def local_search(m,sol,relaxed):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        if relaxed[i] == 0:
            m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def reduce_redundant(neighbor):
    ones_indices = np.where(neighbor == 1)[0]
    num_to_change = len(ones_indices) - int(len(neighbor)*0.2)
    if num_to_change > 0:
        indices_to_change = np.random.choice(ones_indices, size=num_to_change, replace=False)
        neighbor[indices_to_change] = 0
    return neighbor

def solve(m,sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    return m1.objVal

def get_solutions(m, sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i] == sol[i], name=f'fix_u[{i}]')
    m1.optimize()
    sols = m1.getAttr('X', m1.getVars())
    sols = torch.tensor(sols)  # Convert to PyTorch tensor
    sols_split = torch.chunk(sols, 3)
    return sols_split

def get_negative(m,num_negative,tle):
    m.setParam('OutputFlag',0)
    m.setParam('MIPGap', 0.1)
    m.setParam('PoolSearchMode', 2)
    m.setParam('PoolSolutions', num_negative)
    m.setParam('TimeLimit', tle)
    m.optimize()
    u=m._u

    if m.SolCount > 0:
        negatives = []
        
        for sn in range(m.SolCount):
            m.setParam('SolutionNumber',sn)
            sol = np.round(m.getAttr("Xn", u)).astype(int).tolist()
            negatives.append(sol)
        # negatives=np.array(negatives)
        return negatives
    return []

def process(G):
    file,json_path,uc = G
    with open(os.path.join(json_path, file),'r') as f:
        data = json.load(f)
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    m = uc.get_3bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=on_off,Ui0=u0,Pi0=p0)
    N=uc.NumThermal
    T=uc.HorizonLen
    u=m.getVars()[:N*T]
    m._u = u
    negative_datasets=[]
    tle=60
    while len(negative_datasets)<2:
        negative_datasets = get_negative(m,10,tle)
        tle*=1.6
    data['negative_datasets']=negative_datasets
    with open(os.path.join(json_path, file),'w') as f:
        json.dump(data,f)



#主函数
def main():
    instance = '1080_c30_based_8_std'
    dirs=['train','valid','test']
    num_perturb = 20#一个MILP生成多少个例子
    CORE_NUM = 50
    uc_path = f'UC_AF/{instance}.mod'
    uc = UC(uc_path)
    
    for dir in dirs:
        json_path = os.path.join(f'datasets/{instance}/json',dir)

        json_files = os.listdir(json_path)
        move = [(file,json_path,uc) for file in json_files if file.endswith('.json')]

        with Progress(
            "[progress.description]{task.description}({task.completed}/{task.total})",
            BarColumn(),
            "[progress.percentage]{task.percentage:>3.2f}%",
            TimeElapsedColumn(),
            '<',
            TimeRemainingColumn(),
        ) as progress:
            task_id = progress.add_task(f"[cyan]Processing {dir} files...", total=len(move))

            with Pool(processes=CORE_NUM) as pool:
                for _ in pool.imap_unordered(process, move):

                    progress.update(task_id, advance=1)


if __name__ == "__main__":
    main()