import sys
sys.path[0]+='/..'
import gurobipy as gp
import numpy as np
from uc_class import UC
import torch
from utilities import *
import os

from concurrent.futures import ThreadPoolExecutor
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn

from rich import print
from multiprocessing import Pool


# name = '50_0_1_w'
name = '5_std'

# name = '10_std'
# name = '20_0_1_w'
file = 'UC_AF/'+name+'.mod'
Dt=np.loadtxt('deman/pd.csv',delimiter=',',encoding='utf-8-sig')
b3=UC(file)
sys_up=sum(b3.ThPimax)*0.8
sys_low=sys_up*0.4

pd=(Dt-Dt.min())/(Dt.max()-Dt.min())*0.85*(sys_up-sys_low)+sys_low*1.05

TLE=1200
CORE_NUM=20

u0_save=np.load(f'instances/fixed/{name}/u0_save.npy')
p0_save=np.load(f'instances/fixed/{name}/p0_save.npy')
onoff_save=np.load(f'instances/fixed/{name}/onoff_save.npy')

days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
cumulative_days = [0] + [sum(days_in_month[:i+1]) for i in range(len(days_in_month))]


def gen_by_3bin(G):
    # with gp.Env() as env, gp.Model(env=env) as m:
        cur,seed,dt,u0,p0,onoff = G

        month = next(i for i, cum_day in enumerate(cumulative_days) if cum_day > cur)
        os.makedirs(f'newdatasets/{name}/3bin/test/{month}/', exist_ok=True)
        os.makedirs(f'newdatasets/{name}/3bin/train/{month}/', exist_ok=True)


        print(f"in{cur}_{seed}")
        np.random.seed(seed)

        Dt=np.empty(len(dt))
        cnt=1

        cnt+=1
        for i in range(len(dt)):
            Dt[i]=max(sys_low,min(sys_up,np.random.uniform(dt[i]*0.995,dt[i]*1.005)))
        Dt*=np.random.uniform(0.99,1.01)
        Spin = Dt*0.1
        
        m=b3.get_3bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=onoff,Ui0=u0,Pi0=p0)
        # m1=b3.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=onoff,Ui0=u0,Pi0=p0)
        N=b3.NumThermal
        T=b3.HorizonLen


        m.setParam("OutputFlag", 0)
        m.setParam("MIPGap", 1e-3)
        m.Params.Threads = 1
        m.Params.TimeLimit = TLE
        m.Params.PoolSolutions = 10
        m.Params.PoolSearchMode = 2
        m.optimize()

        print(cur,seed,m.Status)
        if m.Status==2:            
            n=m.SolCount
            objs=np.zeros(n)
            sols=np.zeros((n, N*T))
            for sn in range(n):
                m.Params.SolutionNumber = sn
                uv=m.getVars()[:N*T]
                sols[sn]=m.getAttr("Xn", uv)
                objs[sn]=m.PoolObjVal
            optsol = m.getAttr("X", uv)
            objs = objs/objs.min()
            exp_weight = np.exp(objs)
            weight = exp_weight/exp_weight.sum()
            weight[0]=1-np.sum(weight[1:])
            weighted_sol = np.matmul(weight,sols)
            A_indices, A_values, v_nodes, c_nodes, b_vars=get_fea(m)
            torch.save({
                    'A_indices':A_indices,
                    'A_values':A_values,
                    'v_nodes':v_nodes,
                    'c_nodes':c_nodes,
                    'b_vars':b_vars,
                    'weighted_sol':weighted_sol
                },f'newdatasets/{name}/3bin/train/{month}/{cur}_{seed}.pt')
            # A_indices1, A_values1, v_nodes1, c_nodes1, b_vars1=get_fea(m1)
            # torch.save({
            #         'A_indices':A_indices1,
            #         'A_values':A_values1,
            #         'v_nodes':v_nodes1,
            #         'c_nodes':c_nodes1,
            #         'b_vars':b_vars1,
            #         'weighted_sol':weighted_sol
            #     },f'datasets/{name}/1bin/{path}/{cur}_{seed}.pt')
            # torch.save({
            #         'A_indices':A_indices1,
            #         'A_values':A_values1,
            #         'v_nodes':v_nodes1,
            #         'c_nodes':c_nodes1,
            #         'b_vars':b_vars1,
            #         'weighted_sol':weighted_sol
            #     },f'datasets/{name}_opt/1bin/{path}/{cur}_{seed}.pt')
            if seed<5:
                m.write(f'newdatasets/{name}/3bin/test/{month}/{cur}_{seed}.lp')
            # print(True)
            return True
        return False


def gen(day):
    move = [(i, j, pd[i], u0_save[i], p0_save[i], onoff_save[i]) for i in range(0, day) for j in range(30)]
    cnt=0
    # 创建进度条对象
    with Progress(
        "[progress.description]{task.description}({task.completed}/{task.total})",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.2f}%",
        TimeElapsedColumn(),
        '<',
        TimeRemainingColumn(),
) as progress:
        # 创建 ThreadPoolExecutor，使用它来并发执行任务
        with Pool(processes=CORE_NUM) as pool:
            for _ in progress.track(pool.imap(gen_by_3bin, move), total=len(move)):
                if _==False:
                    cnt+=1
                print(f'有{cnt}个失败')

    



os.makedirs(f'newdatasets/{name}/3bin/', exist_ok=True)
os.makedirs(f'newdatasets/{name}/3bin/train/', exist_ok=True)
os.makedirs(f'newdatasets/{name}/3bin/test/', exist_ok=True)


gen(365)

# print(onoff_save[120][33])
# print(p0_save[120][33])
# print(u0_save[120][33])