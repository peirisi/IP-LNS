import sys
sys.path[0]+='/..'
import gurobipy as gp
import numpy as np
from uc_class import UC
import torch
from utilities import *
import os
import json
from concurrent.futures import ThreadPoolExecutor
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn

from rich import print
from multiprocessing import Pool


# name = '50_0_1_w'
# name = '10_5*2_std'
# name = '5_std'

# name = '8_std'
# name = '1080_c30_based_8_std'

# name = '200_0_1_w'
# name = '80_c11_based_8_std'
name = '1080_c30_based_8_std'
file = 'UC_AF/'+name+'.mod'
Dt=np.loadtxt('deman/pd.csv',delimiter=',',encoding='utf-8-sig')
b3=UC(file)

N = b3.NumThermal
T = b3.HorizonLen
sys_up=sum(b3.ThPimax)*0.9
sys_low=sys_up*0.4
pd=(Dt-Dt.min())/(Dt.max()-Dt.min())*0.95*(sys_up-sys_low)+sys_low

TLE=3600
CORE_NUM=50

u0_save=np.load(f'instances/fixed/{name}/u0_save.npy')
p0_save=np.load(f'instances/fixed/{name}/p0_save.npy')
onoff_save=np.load(f'instances/fixed/{name}/onoff_save.npy')

def mycallback(model, where):
    
    if where == gp.GRB.Callback.MIPSOL:
        obj = model.cbGet(gp.GRB.Callback.MIPSOL_OBJ)
        sol = model.cbGetSolution(model._u)
        model._objs.append(obj)
        model._sols.append(sol)
    
def get_positive(m,num_positive):
    m.setParam('OutputFlag', 0)
    m.setParam('MIPGap', 1e-7)
    m.setParam('PoolSearchMode', 2)
    m.setParam('PoolSolutions', num_positive)
    m.setParam('TimeLimit', TLE)

    u=m._u
    m.optimize(mycallback)
    objs = []
    if m.SolCount > 0:
        positives = []
        for sn in range(m.SolCount):
            m.setParam('SolutionNumber', sn)
            sol = np.round(m.getAttr("Xn", u)).astype(int).tolist()
            positives.append(sol)
            objs.append(m.PoolObjVal)
        # positives = np.array(positives)
        return positives,np.mean(objs)
    return [],np.mean(objs)

def get_negative(m,num_negative):
    m.setParam('OutputFlag',0)
    m.setParam('MIPGap', 1e-2)
    m.setParam('PoolSearchMode', 2)
    m.setParam('PoolSolutions', num_negative)
    m.setParam('TimeLimit', 20)
    m.optimize()
    u=m._u

    if m.SolCount > 0:
        negatives = []
        
        for sn in range(m.SolCount):
            m.setParam('SolutionNumber',sn)
            # u=m.getVars()[:len(m.getVars())//3]
            sol = np.round(m.getAttr("Xn", u)).astype(int).tolist()
            negatives.append(sol)
        # negatives=np.array(negatives)
        return negatives
    return []



def gen_by_3bin(G):
    # with gp.Env() as env, gp.Model(env=env) as m:
        cur,seed,dt,u0,p0,onoff = G
        
        print(f"in{cur}_{seed}")
        path='train'
        if cur % 10 == 3:
            path='valid'
        elif cur % 10 ==7:
            path='test'

        u0 = [int(u) for u in u0]
        p0 = [float(p) for p in p0]
        onoff = [int(o) for o in onoff]

        np.random.seed(seed)

        Dt=np.empty(len(dt))
        for i in range(len(dt)):
            Dt[i]=max(sys_low,min(sys_up,np.random.uniform(dt[i]*0.95,dt[i]*1.05)))
        Dt*=np.random.uniform(0.95,1.05)
        Spin = Dt*0.1
        m=b3.get_3bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=onoff,Ui0=u0,Pi0=p0)
        # m1=b3.get_1bin_model(Dt=Dt,Spin=Spin,ThTime_on_off_init=onoff,Ui0=u0,Pi0=p0)
        N=b3.NumThermal
        T=b3.HorizonLen

        Dt = Dt.tolist()
        Spin = Spin.tolist()
        

        m.setParam("OutputFlag", 0)
        m.setParam("MIPGap", 1e-6)
        m.Params.Threads = 1
        m.Params.TimeLimit = TLE
        m.Params.PoolSolutions = 10
        m.Params.PoolSearchMode = 2
        # m.optimize()
        u=m.getVars()[:N*T]
        m._u = u
        m._objs=[]
        m._sols=[]
        negative_datasets = get_negative(m,10)
        positive_datasets,mean_obj = get_positive(m,10)

        print(cur,seed,m.Status)

        if m.Status==2 or m.Status==9:            
            n=m.SolCount
            objs=np.zeros(n)
            sols=np.zeros((n, N*T))
            for sn in range(n):
                m.Params.SolutionNumber = sn
                uv=m.getVars()[:N*T]
                sols[sn]=m.getAttr("Xn", uv)
                objs[sn]=m.PoolObjVal
            optsol = np.round(m.getAttr("X", uv)).tolist()
            objs = objs/objs.min()
            exp_weight = np.exp(objs)
            weight = exp_weight/exp_weight.sum()
            weight[0]=1-np.sum(weight[1:])
            weighted_sol = np.round(np.matmul(weight,sols), decimals=3).tolist()
            

            sol_list = []
            obj_list = []
            for obj,sol in zip(m._objs,m._sols):
                if (obj - mean_obj)/obj > 1e-5:
                    sol_list.append(sol)
                    obj_list.append(obj)
      
            with open(f'datasets/{name}/json/{path}/{cur}_{seed}.json', 'w') as f:
                json.dump({
                    'weighted_sol':weighted_sol,
                    'opt_sol':optsol,
                    'obj':float(m.objVal),
                    'Dt':Dt,
                    'Spin':Spin,
                    'u0':u0,
                    'p0':p0,
                    'on_off':onoff,
                    'instance': name,
                    'sol_list': sol_list,
                    'obj_list': obj_list,
                    'positive_datasets': positive_datasets,
                    'negative_datasets': negative_datasets,
                        }, f)
            return True
        return False

def gen(day):
    move = [(i, j, pd[i], u0_save[i], p0_save[i], onoff_save[i]) for i in range(day) for j in range(1)]
    cntf=0
    cntt=0
    # 创建进度条对象
    with Progress(
        "[progress.description]{task.description}({task.completed}/{task.total})",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.2f}%",
        TimeElapsedColumn(),
        '<',
        TimeRemainingColumn(),
    ) as progress:
        task_id = progress.add_task("[cyan]Processing ps3bin files...", total=len(move))
        
        # 创建 ThreadPoolExecutor，使用它来并发执行任务
        with Pool(processes=CORE_NUM) as pool:
            for _ in pool.imap_unordered(gen_by_3bin, move):
                progress.update(task_id, advance=1)
                task = progress.tasks[task_id]  # Get the Task object
                print(f'Progress: {task.completed}/{task.total}')  # 打印当前进度
                if _==False:
                    cntf+=1
                else:
                    cntt+=1
                # print(f'有{cntf}个失败 {cntt}个成功')


# def gen(day):
#     move = [(i, j, pd[i], u0_save[i], p0_save[i], onoff_save[i]) for i in range(day) for j in range(20)]
#     cntf=0
#     cntt=0
#     # 创建进度条对象
#     with Progress(
#         "[progress.description]{task.description}({task.completed}/{task.total})",
#         BarColumn(),
#         "[progress.percentage]{task.percentage:>3.2f}%",
#         TimeElapsedColumn(),
#         '<',
#         TimeRemainingColumn(),
#     ) as progress:
#         task = progress.add_task("[cyan]Processing ps3bin files...", total=len(move))
        
#         # 创建 ThreadPoolExecutor，使用它来并发执行任务
#         with Pool(processes=CORE_NUM) as pool:
#             for _ in pool.imap_unordered(gen_by_3bin, move):
#                 progress.update(task, advance=1)
#                 if _==False:
#                     cntf+=1
#                 else:
#                     cntt+=1
#                 # print(f'有{cntf}个失败 {cntt}个成功')

os.makedirs(f'datasets/{name}/json/train/', exist_ok=True)
os.makedirs(f'datasets/{name}/json/valid/', exist_ok=True)
os.makedirs(f'datasets/{name}/json/test/', exist_ok=True)
   

# print(u0_save.shape)

gen(365)