import sys
sys.path[0]+='/..'
import numpy as np
import os
from multiprocessing.dummy import Pool as ThreadPool
from utilities import *
from uc_class import UC


from rich import print
from rich.progress import Progress, BarColumn, SpinnerColumn, TimeRemainingColumn, TimeElapsedColumn



# name = '50_0_1_w'
# name = '8_std'
# name = '100_0_1_w'
name = '80_c11_based_8_std'
# name = 'c30_1080_based_8_std'
file = 'UC_AF/'+name+'.mod'
# uc = UC(file)
Dt=np.loadtxt('deman/pd.csv',delimiter=',',encoding='utf-8-sig')
b3=UC(file)

N = b3.NumThermal
T = b3.HorizonLen
sys_up=sum(b3.ThPimax)*0.8
sys_low=sys_up*0.4
pd=(Dt-Dt.min())/(Dt.max()-Dt.min())*0.85*(sys_up-sys_low)+sys_low*1.05
TLE=3600
CORE_NUM=50
n=365




cnt=0
u0_save=[]
p0_save=[]
onoff_save=[]
pmin = np.array(b3.ThPimin)

if not os.path.isdir(f'instances/fixed'):
    os.mkdir(f'instances/fixed')
if not os.path.isdir(f'instances/fixed/{name}'):
    os.mkdir(f'instances/fixed/{name}')

with Progress(
        "[progress.description]{task.description}({task.completed}/{task.total})",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.2f}%",
        TimeElapsedColumn(),
        '<',
        TimeRemainingColumn(),
    ) as progress:
    description = "making instance"
    task = progress.add_task(description, total=n)
    for i in range(n):

        progress.update(task, completed=i, description=description)
        Dt=pd[i]
        Spin = Dt*0.1
        #初始化upo
        p0=b3.Pi0
        u0=b3.Ui0
        onoff=b3.ThTime_on_off_init
        m=b3.get_3bin_model(Dt=Dt,Spin=Spin,Ui0=u0,Pi0=p0,ThTime_on_off_init=onoff)
        m.setParam("OutputFlag", 0)
        m.setParam("TLE",TLE)
        m.setParam("MIPGap",1e-3)
        m.optimize()
        u0_save.append(u0)
        p0_save.append(p0)
        onoff_save.append(onoff)
        
        if m.status == 2 or m.status == 9:
            u0,p0,onoff = cal_upo(m)
            b3.change_state(p0=p0,onoff=onoff)
            cnt+=1
        rmin = u0*pmin
        check = (rmin<=p0).all()
        print(check)
        if not check:
            print(u0,p0,rmin)
            break
        progress.update(task, completed=cnt, description='finish instance making')
        print(i,m.status)

u0_save=np.array(u0_save)
p0_save=np.array(p0_save)
onoff_save=np.array(onoff_save)
np.save(f'instances/fixed/{name}/u0_save',u0_save)
np.save(f'instances/fixed/{name}/p0_save',p0_save)
np.save(f'instances/fixed/{name}/onoff_save',onoff_save)
print(f'finish {name}')