import numpy as np
import torch
from gurobipy import GRB
from uc_class import UC
import gurobipy as gp
import os
import collections
from torch_geometric.data import HeteroData


def cal_upo(m):
    mvars = m.getVars()
    u=[]
    p=[]
    for i in range(len(mvars)):
        if 'u'in mvars[i].Varname:
            u.append(mvars[i])
        if 'p['in mvars[i].Varname:
            p.append(mvars[i])

    px = np.round(np.array(m.getAttr("X", p), dtype=float), decimals=3).reshape(-1, 24)
    ux = np.around(m.getAttr("X", u)).astype(int).reshape(-1,24)
    n=px.shape[0]
    
    p0=[float(px[i][-1]) for i in range(n)]
    u0=[int(ux[i][-1]) for i in range(n)]

    onoff=[]
    for i in range(n):
        k = 1 if ux[i][-1]==1 else -1
        num=1
        for j in range(2,25):
            if ux[i][-j]==ux[i][1-j]:
                num+=1
            else:
                break
        onoff.append(k*num)
    return u0,p0,onoff

def get_fea(m):
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = m.getA().tocoo()
    values = coo.data
    indices = np.vstack((coo.row, coo.col))
    i = torch.LongTensor(indices)
    v = torch.FloatTensor(values)
    A = torch.sparse_coo_tensor(i, v, coo.shape)
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5),1)
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1)
    return A._indices(), A._values().unsqueeze(1), v_nodes.float(), c_nodes.float(), b_vars

def get_edge_index(N,T):

    source_node=[]
    target_node=[]
    for i in range(N):
        for t in range(T):
            j=i*T+t
            source_node.append(j)
            target_node.append(j)
            source_node.append(j+N*T)
            target_node.append(j)
            source_node.append(j+2*N*T)
            target_node.append(j)
            source_node.append(j+3*N*T)
            target_node.append(j)
            source_node.append(j+4*N*T)
            target_node.append(j)
            for ii in range(N):
                if ii != i:
                    source_node.append(ii*T+t)
                    target_node.append(j)
            for tt in range(T):
                if tt != t:
                    source_node.append(i*T+tt)
                    target_node.append(j)
    edge_index=torch.tensor([source_node,target_node], dtype=torch.long)
    return edge_index


def get_pmax_pmin_spin(path,m):
    spin=[0 for i in range(24)]
    constrs = m.getConstrs()
    for i in constrs:
        if 'System_spinning_reserve_requirement' in i.ConstrName:
            #System_spinning_reserve_requirement后面中括号里的数字表示下标
            spin[int(i.ConstrName.split('[')[1].split(']')[0])]=-m.getAttr("RHS", [i])[0]
    uc = UC(path)
    pmax = uc.ThPimax
    pmin = uc.ThPimin
    # spin = uc.Spin
    return pmax,pmin,spin

def get_pmax_spin(m,N,T):
    #找出名字包含System_spinning_reserve_requirement的约束
    spin=[0 for i in range(T)]
    pmax=[]
    constrs = m.getConstrs()
    u0 = m.getVars()[:N*T:T]
    for i in constrs:
        if 'System_spinning_reserve_requirement' in i.ConstrName:
            #System_spinning_reserve_requirement后面中括号里的数字表示下标
            spin[int(i.ConstrName.split('[')[1].split(']')[0])]=-m.getAttr("RHS", [i])[0]
            if int(i.ConstrName.split('[')[1].split(']')[0])==0:
                for var in u0:
                    pmax.append(-m.getCoeff(i, var))
    return pmax,spin
    # uc = UC(path)
    # pmax = uc.ThPimax
    # pmin = uc.ThPimin
    # spin = uc.Spin
    # return pmax,pmin,spin

def get_on_off(path):
    # path = f'UC_AF/{name}.mod'
    uc = UC(path)
    on = uc.ThTime_on_min
    off = uc.ThTime_off_min
    return on,off

def get_pmin(path):
    uc = UC(path)
    pmin = uc.ThPimin
    return pmin

def get_shutdown(path):
    uc = UC(path)
    p_shut = uc.Pishutdown
    return p_shut

def feasibility_restore(m,ans):
    vars = m.getVars()[:len(ans)]
    # tmp = m.addVars(len(ans), vtype=GRB.CONTINOUS, name='tmp')
    alphas=[]
    for i,v in enumerate(vars):
        if ans[i] == 0 or ans[i] == 1:
            tmp_var = m.addVar(vtype=GRB.CONTINUOUS,name=f'alpha{v.VarName}',obj=1000)
            m.addConstr(tmp_var >= v - ans[i], name=f'alpha_up_{v.VarName}')
            m.addConstr(tmp_var >= ans[i] - v, name=f'alpha_dowm_{v.VarName}')
            alphas.append(tmp_var)
    # m.setObjective(sum(alphas), GRB.MINIMIZE)
    #向目标函数中添加最小化alpha的和
    
    # m.Objective(sum(alphas), GRB.MINIMIZE)

    # m.write('TMPTMPTMPTMPTMP.lp')
    # m.setParam('OutputFlag', 1)
    # m.optimize()
    return m

def he_fs(m,sol,k,instance):
    instance_variabels = m.getVars()
    T=24
    N=int(len(sol)/T)
    # pmax1,spin1 = get_pmax_spin(m,N,T)
    # pmin = pmax
    if os.path.exists(f'./UC_AF/{instance}.mod'):
        pmax,pmin,spin = get_pmax_pmin_spin(f'./UC_AF/{instance}.mod',m)
    else:
        pmax,pmin,spin = get_pmax_pmin_spin(f'../UC_AF/{instance}.mod',m)


    ans = [0.5 for i in range(N*T)]
    for t in range(T):
        p_list=[]
        for i,idx in enumerate(range(t,N*T,T)):
            p_list.append((sol[idx],pmax[i],idx,pmin[i]))
        #从大到小排序
        p_list.sort(key=lambda x:x[0], reverse=True)
        sumpmax=0
        sumpmin=0
        k1=0
        kt=0
        for i in range(len(p_list)):
            sumpmax+=p_list[i][1]
            if k1==0 and sumpmax>=spin[t]:
                k1=i+1
            sumpmin+=p_list[i][3]
            if kt==0 and sumpmin>=spin[t]:
                kt=i+1
        # k1 = int(k1*1.1)
        # k0 = int((N-k1)*k)
        # k1 = int(k1*k)

        #取出p_list中排序后的idx
        idx_prior = [p[2] for p in p_list]
        # k1 = int(k1*0.9)
        # k0 = int(k0*0.9)
        #遍历idx_prior的前k1个元素
        
        for idx in idx_prior[:k1]:
            ans[idx]=1
 
        # for l in range(max(kt,N-k0),N):
        #     ans[idx_prior[l]]=0
        
        # for idx in idx_prior[-k0:]:
        #     ans[idx]=0
            
            # m.addConstr(instance_variabels[idx] == 0, name=f'alpha{instance_variabels[idx].VarName}')
    # m.update()
    return ans

def fix_variable(m,ans):
    instance_variabels = m.getVars()[:len(ans)]
    p0,p1 = 0,0
    for i in range(len(ans)):
        if ans[i]==0 or ans[i]==1:
            if ans[i]==0:
                p0+=1
            else:
                p1+=1
            m.addConstr(instance_variabels[i] == ans[i], name=f'alpha_{instance_variabels[i].VarName}')
    m.update()
    # print(p0/len(ans),p1/len(ans))
    return m

def projection_feasiable(m,ans):
    v = m.getVars()[:len(ans)]
    p0,p1 = 0,0
    alpha = []
    for i in range(len(ans)):
        if ans[i]==0 or ans[i]==1:
            if ans[i]==0:
                p0+=1
            else:
                p1+=1
            tmp_var = m.addVar(vtype=GRB.CONTINUOUS,name=f'alpha{v[i].VarName}')
            alpha.append(tmp_var) 
            m.addConstr(tmp_var >= v[i] - ans[i], name=f'alpha_up_{v[i].VarName}')
            m.addConstr(tmp_var >= ans[i] - v[i], name=f'alpha_dowm_{v[i].VarName}')
            # m.addConstr(instance_variabels[i] == ans[i], name=f'alpha_{instance_variabels[i].VarName}')
    m.setObjective(sum(alpha), GRB.MINIMIZE)
    m.update()
    # print(p0/len(ans),p1/len(ans))
    return m


def soft_fix_variable(m,ans):
    v = m.getVars()[:len(ans)]
    p0,p1 = 0,0
    alpha = []
    f1=m.getObjective()
    for i in range(len(ans)):
        if ans[i]==0 or ans[i]==1:
            if ans[i]==0:
                p0+=1
            else:
                p1+=1
            tmp_var = m.addVar(vtype=GRB.CONTINUOUS,name=f'alpha{v[i].VarName}')
            alpha.append(tmp_var) 
            m.addConstr(tmp_var >= v[i] - ans[i], name=f'alpha_up_{v[i].VarName}')
            m.addConstr(tmp_var >= ans[i] - v[i], name=f'alpha_dowm_{v[i].VarName}')
            # m.addConstr(instance_variabels[i] == ans[i], name=f'alpha_{instance_variabels[i].VarName}')
    m.setObjective(sum(alpha)*100+f1*0.01, GRB.MINIMIZE)
    m.update()
    # print(p0/len(ans),p1/len(ans))
    return m

# def restore_on_off(ans,instance,day):
#     if os.path.exists(f'../instances/fixed/{instance}/onoff_save.npy'):
#         onoff=np.load(f'../instances/fixed/{instance}/onoff_save.npy')[day]
#     else:
#         onoff=np.load(f'./instances/fixed/{instance}/onoff_save.npy')[day]

    
#     T=24
#     N=int(len(ans)/T)
#     if os.path.exists(f'./UC_AF/{instance}.mod'):
#         on,off = get_on_off(f'./UC_AF/{instance}.mod')
#     else:
#         on,off = get_on_off(f'../UC_AF/{instance}.mod')
#     for i in range(N):
#         t=0
#         while t<T:
#             cnt0=0
#             l=0
#             while t+l<T and ans[i*T+t+l]==0:
#                 l+=1
#                 cnt0+=1

#             if cnt0>0 and t==0:
#                 cnt0+=max(0,-onoff[i])

#             if cnt0>0 and cnt0<off[i]:
                
#                 for ll in range(l):
#                     ans[i*T+t+ll]=0.5
#             t+=l
#             while t<T and ans[i*T+t]!=0:
#                 t+=1

#         t=0
#         while t<T:
#             cnt1=0
#             l=0
#             while t+l<T and ans[i*T+t+l]==1:
#                 l+=1
#                 cnt1+=1
#             if cnt1>0 and t==0:
#                 cnt1+=max(0,onoff[i])
#             if cnt1>0 and cnt1<on[i]:
#                 res = on[i]-cnt1
#                 for ll in range(1,res+1):
#                     idx = t-ll
#                     if idx<0:
#                         break
#                     if ans[i*T+idx]==0:
#                         ans[i*T+idx]=0.5
#                 for ll in range(1,res+1):
#                     idx = t+l+ll
#                     if idx>=T:
#                         break
#                     if ans[i*T+idx]==0:
#                         ans[i*T+idx]=0.5
#             t+=l
#             while t<T and ans[i*T+t]!=1:
#                 t+=1
        


#         t=0
#         while t<T-1:
#             if ans[i*T+t] + ans[i*T+t+1]==1 and ans[i*T+t] != ans[i*T+t+1]:
#                 ans[i*T+t]=0.5
#                 ans[i*T+t+1]=0.5
#                 t+=1
#             t+=1
#     return ans

# def remove_initial(ans, m):
#     constraints = m.getConstrs()

#     T=24
#     N=int(len(ans)/T)
#     for c in constraints:
#         if 'Initial_status_of_units' in c.ConstrName:
#             # Split the constraint name on '[' to separate the name from the numbers
#             parts = c.ConstrName.split('[')
#             # The second part should now be '33,0]', so we can split on ',' to get the numbers
#             numbers = parts[1].rstrip(']').split(',')
#             # Convert the numbers to integers
#             i = int(numbers[0])
#             t = int(numbers[1])
#             # Now you can use unit_number and time_number
#             ans[i*T+t]=0.5
#         if 'Ramp_rate_limits2' in c.ConstrName and c.ConstrName.endswith(',0]'):
#             #取右端项
#             rhs = c.RHS
#             # Split the constraint name on '[' to separate the name from the numbers
#             parts = c.ConstrName.split('[')
#             # The second part should now be '33,0]', so we can split on ',' to get the numbers
#             numbers = parts[1].rstrip(']').split(',')
#             # Convert the numbers to integers
#             i = int(numbers[0])
#             #获得左端项
#             d = m.getVarByName(f'd[{i},0]')
#             # print(c,d)
#             coeff = m.getCoeff(c, d)
#             # print(f'coeff:{coeff},rhs:{rhs}')

#             if rhs!=0:
#                 # ans[i*T]=1
#                 coeff=abs(coeff)
#                 rhs=abs(rhs)
#                 res = int(rhs//coeff)
#                 for t in range(res+2):
#                     ans[i*T+t]=1
                    
    
#     return ans

# def restore_initial(ans,p0,rd,sd,on_off,on,off):#-1表示不可开机
#     N=ans.shape[0]
#     T=ans.shape[1]
#     for i in range(N):
#         if on_off[i]<0:
#             for t in range(off[i]+on_off[i]):#还需关机
#                 ans[i][t]=-1
#         elif on_off[i]>0:
#             for t in range(on[i]-on_off[i]):#还需开机
#                 ans[i][t]=1
#         if p0[i]>sd[i]:#最快下坡还需开机
#             # print((p0[i]-sd[i]+rd[i]-1)//rd[i])
#             for t in range(int((p0[i]-sd[i]+rd[i]-1)//rd[i])):#向上取整
#                 ans[i][t]=1
#         if on_off[i]<0 and -on_off[i]<off[i]:
#             res = off[i]+on_off[i]
#             for t in range(res):
#                 ans[i][t]=-1
#         if on_off[i]>0 and on_off[i]<on[i]:
#             res = on[i]-on_off[i]
#             for t in range(res):
#                 ans[i][t]=1
#     return ans

# def restore_spin_new(ans,spin,dt,pmax):#可以接受小数与负数#后面考虑先开预测值大的机组
#     N=ans.shape[0]
#     T=ans.shape[1]
#     for t in range(T):
#         cur_max = 0
#         for i in range(N):
#             if ans[i][t]>=1-1e-5:
#                 cur_max+=pmax[i]
        
#         if cur_max<spin[t]+dt[t]:
#             p_list=[]
#             for i in range(N):
#                 if ans[i][t]>=0 and ans[i][t]!=1:
#                     p_list.append((ans[i,t],i))
#             p_list.sort(key=lambda x:x[0],reverse=True)
#             for p,i in p_list:
#                 cur_max+=pmax[i]
#                 ans[i][t]=1
#                 if cur_max>=spin[t]+dt[t]:
#                     break
#     return ans

# def restore_on_off(ans,on_off,on,off):#可以接受小数与负数
#     N=ans.shape[0]
#     T=ans.shape[1]
#     for i in range(N):
#         t=0
#         while t<T:#开机时长不够
#             cnt1=0
#             l=0
#             while t+l<T and ans[i,t+l]==1:
#                 l+=1
#                 cnt1+=1
#             if t+l>=T:
#                 break
#             if cnt1>0 and t==0:
#                 cnt1+=max(0,on_off[i])
#             if cnt1>0 and cnt1<on[i]:
#                 res = on[i]-cnt1
#                 dealed=0
#                 for ll in range(1,res+1):#往前开，遇到-1，1就停止
#                     idx = t-ll
#                     if idx<0 or ans[i,idx]==-1 or ans[i,idx]==1:
#                         break
#                     dealed+=1
#                     ans[i,idx]=1
#                 res-=dealed
#                 for ll in range(1,res+1):#往后开不可能遇到-1，遇到1停止
#                     idx = t+l+ll
#                     if idx>=T or ans[i,idx]==1:
#                         break
#                     ans[i,idx]=1
#             t+=l
#             while t<T and ans[i,t]!=1:
#                 t+=1
#         t=0
#         while t<T:#关机时长不够
#             cnt0=0
#             l=0
#             while t+l<T and ans[i,t+l]<1:
#                 l+=1
#                 cnt0+=1
#             if t+l>=T:
#                 break
#             if cnt0>0 and t==0:
#                 cnt0+=max(0,-on_off[i])

#             if cnt0>0 and cnt0<off[i]:
                
#                 for ll in range(l):
#                     ans[i,t+ll]=1
#             t+=l
#             while t<T and ans[i,t]>=1:
#                 t+=1
#     return ans

# def restore_shutdown(ans,m):
#     N=ans.shape[0]
#     T=ans.shape[1]
    
#     r=m.relax()
#     for i in range(N):
#         for t in range(T):
#             r.addConstr(m.getVarByName(f'u[{i},{t}]')==ans[i,t])
#     r.optimize()

# def early_startup(ans,res,t,l2r,su):
#     N=ans.shape[0]
#     #开机向前延长且前面满足最小开机时间
#     sum=0
#     for i in range(N):
#         if l2r[i,t]<0:
#             res-=su[i]
#             sum+=su[i]
#             ans[i,t]=1
#         if res<=0:
#             break
#     return ans,sum


# def delay_shutdown(ans,res,t,r2l,sd):
#     N=ans.shape[0]
#     #开机向后延长且后面满足最小开机时间
#     sum=0
#     for i in range(N):
#         if r2l[i,t]<0:
#             res-=sd[i]
#             sum+=sd[i]
#             ans[i,t]=1
#         if res<=0:
#             break
#     return ans,sum

        

# def com_cont_on_off(ans,on_off,off):
#     N=ans.shape[0]
#     T=ans.shape[1]
#     r2l_off = np.zeros_like(ans)#表示还需要关机几个时段，0以下表示可以开机
#     l2r_off = np.zeros_like(ans)#表示还需要关机几个时段，0以下表示可以开机
#     for i in range(N):
#         if on_off[i]<0:
#             l2r_off[i,0]=off[i]+on_off[i]-1
#         elif ans[i,0]<=0:
#             l2r_off[i,0]=off[i]-1
#         for t in range(1,T):
#             if ans[i,t-1]<1 and ans[i,t]<1:
#                 l2r_off[i,t]=l2r_off[i,t-1]-1
#             elif ans[i,t-1]==1 and ans[i,t]<1:
#                 l2r_off[i,t]=off[i]-1
#     for i in range(N):
#         if ans[i,T-1]<1:
#             r2l_off[i,T-1]=-1
#         for t in range(T-2,-1,-1):
#             if ans[i,t+1]<1 and ans[i,t]<1:
#                 r2l_off[i,t]=r2l_off[i,t+1]-1
#             elif ans[i,t+1]==1 and ans[i,t]<1:
#                 r2l_off[i,t]=off[i]-1
#     return r2l_off,l2r_off

# def restore_spin(ans,spin,dt,pmax):#可以接受小数与负数#后面考虑先开预测值大的机组
#     N=ans.shape[0]
#     T=ans.shape[1]
#     for t in range(T):
#         cur_max = 0
#         for i in range(N):
#             if ans[i][t]>=1-1e-5:
#                 cur_max+=pmax[i]
        
#         if cur_max<spin[t]+dt[t]:
#             p_list=[]
#             for i in range(N):
#                 if ans[i][t]>=0 and ans[i][t]!=1:
#                     p_list.append((ans[i,t],i))
#             p_list.sort(key=lambda x:x[0],reverse=True)
#             for p,i in p_list:
#                 cur_max+=pmax[i]
#                 ans[i][t]=1
#                 if cur_max>=spin[t]+dt[t]:
#                     break
#     return ans

# def restore_ramp(u_close,Dt,Ui0,Pi0,Pidown,Piup,ThPimin,ThPimax,Pistartup,Pishutdown,on_off,off):
#     u = u_close.copy()
#     u[u < 0.9+(1e-5)] = 0
#     N=u.shape[0]
#     T=u.shape[1]
#     with gp.Env(empty=True) as env:
#         env.setParam('OutputFlag', 0)
#         env.start()
#         m = gp.Model(env=env)
#     p = m.addVars(N, T, vtype=GRB.CONTINUOUS, name='p')

#     m.addConstrs((u[i,t]*ThPimin[i] - p[i,t] <= 0  for i in range(N) for t in range (T)), name="Unit_generation_limits1" )
#     m.addConstrs((p[i,t] <= u[i,t]*ThPimax[i]  for i in range(N) for t in range (T)), name="Unit_generation_limits2" )
#     m.addConstrs((p[i,t]-(p[i,t-1]if t>0 else Pi0[i]) <= (u[i,t-1] if t>0 else Ui0[i])*Piup[i] + (u[i,t]-(u[i,t-1] if t>0 else Ui0[i]))*Pistartup[i] +(1-u[i,t])*ThPimax[i]  for i in range(N) for t in range(T)),name="Ramp_rate_limits1" )
#     m.addConstrs(((p[i,t-1]if t>0 else Pi0[i])-p[i,t] <= u[i,t]*Pidown[i] + ((u[i,t-1] if t>0 else Ui0[i])-u[i,t])*Pishutdown[i] +(1-(u[i,t-1] if t>0 else Ui0[i]))*ThPimax[i]  for i in range(N) for t in range(T)),name="Ramp_rate_limits2")

#     m.addConstrs((gp.quicksum(p[i, t] for i in range(N)) - Dt[t]  <= 0 for t in range(T)),name="Power_balance_constrains")

#     m.setObjective(gp.quicksum(Dt[t] - gp.quicksum(p[i,t] for i in range(N)) for t in range(T)), GRB.MINIMIZE)
#     m.update()        
#     m.optimize()
#     p_sum=[0]*T
#     for i in range(N):
#         for t in range(T):
#             p_sum[t]+=p[i,t].x
#     r2l,l2r = com_cont_on_off(u_close,on_off,off)
#     #低成本修复爬坡，不保证完成修复
#     for t in range(T):
#         if p_sum[t]+1e-5<Dt[t]:#ans,res,t,r2l,sd
#             u_close,res = delay_shutdown(u_close,Dt[t]-p_sum[t],t,r2l,Pishutdown)
#             p_sum[t]+=res
#     for t in range(T-1,-1,-1):
#         if p_sum[t]+1e-5<Dt[t]:
#             u_close,res = early_startup(u_close,Dt[t]-p_sum[t],t,l2r,Pistartup)
#             p_sum[t]+=res
#     #高成本修复爬坡，保证完成修复
#     for t in range(T):
#         if p_sum[t]+1e-5<Dt[t]:
#             # for i in range(N-1,-1,-1):                #按优先顺序法固定
#             #     if u_close[i,t]>=0 and u_close[i,t]<1:#不能开启必关机组
#             #         u_close[i,t]=1                      #后面考虑先开预测值大的机组
#             #         p_sum[t]+=Pistartup[i]
#             #         if p_sum[t]>=Dt[t]:
#             #             break
#             p_list=[]
#             for i in range(N):
#                 if u_close[i,t]>=0 and u_close[i,t]<1:
#                     p_list.append((u_close[i,t],i))
#             p_list.sort(key=lambda x:x[0],reverse=True)
#             for p,i in p_list:
#                 u_close[i,t]=1
#                 p_sum[t]+=Pistartup[i]
#                 if p_sum[t]>=Dt[t]:
#                     break
#     return u_close

def get_norm(ori_tensor):
    ori_tensor = ori_tensor.reshape(-1,1)
    norm = torch.norm(ori_tensor, keepdim=True)
    norm_tensor = (ori_tensor/(norm+1e-6))
    return torch.cat((ori_tensor, norm_tensor), dim=1)


# def get_Tripartite_graph_lp(m):
#     r=m.relax()
#     r.setParam('OutputFlag', 0)
#     r.optimize()
#     rvars=r.getVars()
#     constraints=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
#     variables=['u','p','s']
#     A = m.getA()
#     rows, cols = A.shape
#     mvars = m.getVars()
#     constrs = m.getConstrs()
#     b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
#     coo = A.tocoo()
#     v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
#     v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
#     v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
#     v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
#     v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
#     v5 = b_vars.clone().reshape(-1,1)
#     v6 = torch.tensor([v.x for v in rvars]).reshape(-1,1)
#     v_nodes = torch.cat((v0,v1,v2,v3,v4,v5,v6),1).float()
#     c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
#     c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
#     c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
#     c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
#     c_nodes = torch.cat((c0,c1,c2,c3),1).float()

#     tot=int(cols/3)
#     col_slides=collections.defaultdict(int)
#     for v in variables:
#         col_slides[v]=int(tot)
#     row_slides=[]
#     graph = HeteroData()

#     row_slides = collections.defaultdict(int)
#     cons = m.getConstrs()
#     t=0
#     coc=0
#     for c in cons:
#         name=constraints[t]
#         while name not in c.ConstrName:
#             t+=1
#             name=constraints[t]
#         if t>=len(constraints):
#             break
#         row_slides[name]+=1
#     lastv=0
#     for v in variables:
#         graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
#         lastv+=col_slides[v]
#     lastc=0
#     for c in constraints:
#         graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
#         lastc+=row_slides[c]
#     lastr=0
#     for c in constraints:
#         lastc=0
#         for v in variables:
#             mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
#             lastc+=col_slides[v]
#             values = mtx.data
#             if len(values)==0:
#                 continue
#             row_indices = mtx.row
#             col_indices = mtx.col
#             indices = np.vstack((row_indices, col_indices))
#             graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
#             graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
#         lastr+=row_slides[c]

    
#     #o节点
#     graph['obj'].x = torch.tensor([r.objVal]).reshape(-1,1)
#     con_indice=[]
#     con_attr=[]
#     idx=0
#     t=0
#     for c in r.getConstrs():
#         name=constraints[t]
#         while name not in c.ConstrName:
#             if 'edge_attr' in graph['obj','o2c',name]:
#                 graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
#                 graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
#                 graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
#             t+=1
#             name=constraints[t]
#             idx=0
#             con_indice=[]
#             con_attr=[]
#         if t>=len(constraints):
#             break
        
#         if c.Slack < 1e-6:
#             con_indice.append((0,idx))
#             con_attr.append(c.RHS)
#         idx+=1
#     graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
#     graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
#     graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
#     #加入ov边
#     for i,v in enumerate(['u','p','s']):
#         graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1,tot, dtype=torch.int64), torch.arange(0,tot).unsqueeze(0)), 0)
#         graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, tot).unsqueeze(0), torch.zeros(1, tot, dtype=torch.int64)), 0)
#         graph['obj','o2v',v].edge_attr = get_norm(v0[tot*i:tot*(i+1)])

#     return graph

def get_Tripartite_graph_lp(m):
    r=m.relax()
    r.setParam('OutputFlag', 0)
    r.optimize()
    rvars=r.getVars()
    # constraints=['Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
    # variables=['u','p','s']
    variables=[]
    constraints=[]
    mvars = m.getVars()
    constrs = m.getConstrs()
    for v in mvars:
        vname = v.VarName.split('[')[0]
        if vname not in variables:
            variables.append(vname)
    for c in constrs:
        cname = c.ConstrName.split('[')[0]
        cname = cname.rstrip('0123456789')
        if cname not in constraints:
            constraints.append(cname)
    A = m.getA()
    rows, cols = A.shape
    mvars = m.getVars()
    constrs = m.getConstrs()
    b_vars = torch.tensor([1 if 'u'in v.Varname else 0 for v in mvars])
    coo = A.tocoo()
    v0 = torch.tensor(m.getAttr("Obj", mvars)).reshape(-1,1)
    v1 = torch.tensor(coo.getnnz(axis=0)).reshape(-1,1)
    v2 = torch.tensor(coo.sum(axis=0)).reshape(-1,1)/v1
    v3 = torch.tensor(coo.max(axis=0).toarray()).reshape(-1,1)
    v4 = torch.tensor(coo.min(axis=0).toarray()).reshape(-1,1)
    v5 = b_vars.clone().reshape(-1,1)
    v6 = torch.tensor([v.x for v in rvars]).reshape(-1,1)
    v_nodes = torch.cat((v0,v1,v2,v3,v4,v5,v6),1).float()
    c0 = torch.tensor(coo.getnnz(axis=1)).reshape(-1,1)
    c1 = torch.tensor(coo.sum(axis=1)).reshape(-1,1)/c0
    c2 = torch.tensor(m.getAttr("RHS", constrs)).reshape(-1,1)
    c3 = torch.tensor([2 if i=='<' else 1 for i in m.getAttr("Sense", constrs)]).reshape(-1,1)
    c_nodes = torch.cat((c0,c1,c2,c3),1).float()

    tot=int(cols/len(variables))
    col_slides=collections.defaultdict(int)
    for v in variables:
        col_slides[v]=int(tot)
    row_slides=[]
    graph = HeteroData()

    row_slides = collections.defaultdict(int)
    cons = m.getConstrs()
    t=0
    coc=0
    for c in cons:
        name=constraints[t]
        while name not in c.ConstrName:
            t+=1
            name=constraints[t]
        if t>=len(constraints):
            break
        row_slides[name]+=1
    lastv=0
    for v in variables:
        graph[v].x=v_nodes[lastv:lastv+col_slides[v]]
        lastv+=col_slides[v]
    lastc=0
    for c in constraints:
        graph[c].x=c_nodes[lastc:lastc+row_slides[c]]
        lastc+=row_slides[c]
    lastr=0
    for c in constraints:
        lastc=0
        for v in variables:
            mtx = A[lastr:lastr+row_slides[c],lastc:lastc+col_slides[v]].tocoo()
            lastc+=col_slides[v]
            values = mtx.data
            if len(values)==0:
                continue
            row_indices = mtx.row
            col_indices = mtx.col
            indices = np.vstack((row_indices, col_indices))
            graph[c,'c2v',v].edge_index = torch.from_numpy(indices)
            graph[c,'c2v',v].edge_attr = torch.from_numpy(values).reshape(-1,1)
        lastr+=row_slides[c]

    
    #o节点
    graph['obj'].x = torch.tensor([r.objVal]).reshape(-1,1)
    con_indice=[]
    con_attr=[]
    idx=0
    t=0
    for c in r.getConstrs():
        name=constraints[t]
        while name not in c.ConstrName:
            if 'edge_attr' in graph['obj','o2c',name]:
                graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
                graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
                graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
            t+=1
            name=constraints[t]
            idx=0
            con_indice=[]
            con_attr=[]
        if t>=len(constraints):
            break
        
        if c.Slack < 1e-6:
            con_indice.append((0,idx))
            con_attr.append(c.RHS)
        idx+=1
    graph['obj','o2c',name].edge_index = torch.tensor(con_indice).t()
    graph[name,'c2o','obj'].edge_index = torch.tensor(con_indice).t()[[1,0]]
    graph['obj','o2c',name].edge_attr = get_norm(torch.tensor(con_attr).reshape(-1,1))
    #加入ov边
    for i,v in enumerate(['u','p','s']):
        graph['obj','o2v',v].edge_index = torch.cat((torch.zeros(1,tot, dtype=torch.int64), torch.arange(0,tot).unsqueeze(0)), 0)
        graph[v,'v2o','obj'].edge_index = torch.cat((torch.arange(0, tot).unsqueeze(0), torch.zeros(1, tot, dtype=torch.int64)), 0)
        graph['obj','o2v',v].edge_attr = get_norm(v0[tot*i:tot*(i+1)])

    return graph


def restore_initial(ans,p0,rd,sd,on_off,on,off):#-1表示不可开机
    N=ans.shape[0]
    T=ans.shape[1]
    for i in range(N):
        if on_off[i]<0:
            for t in range(off[i]+on_off[i]):#还需关机
                ans[i][t]=-1
        elif on_off[i]>0:
            for t in range(on[i]-on_off[i]):#还需开机
                ans[i][t]=1
        if p0[i]>sd[i]:#最快下坡还需开机
            # print((p0[i]-sd[i]+rd[i]-1)//rd[i])
            for t in range(int((p0[i]-sd[i]+rd[i]-1)//rd[i])):#向上取整
                ans[i][t]=1
        if on_off[i]<0 and -on_off[i]<off[i]:
            res = off[i]+on_off[i]
            for t in range(res):
                ans[i][t]=-1
        if on_off[i]>0 and on_off[i]<on[i]:
            res = on[i]-on_off[i]
            for t in range(res):
                ans[i][t]=1
    return ans

def restore_spin(ans,spin,dt,pmax):#可以接受小数与负数#后面考虑先开预测值大的机组
    N=ans.shape[0]
    T=ans.shape[1]
    for t in range(T):
        cur_max = 0
        for i in range(N):
            if ans[i][t]>=1-1e-5:
                cur_max+=pmax[i]
        
        if cur_max<spin[t]+dt[t]:
            p_list=[]
            for i in range(N):
                if ans[i][t]>=0 and ans[i][t]!=1:
                    p_list.append((ans[i,t],i))
            p_list.sort(key=lambda x:x[0],reverse=True)
            for p,i in p_list:
                cur_max+=pmax[i]
                ans[i][t]=1
                if cur_max>=spin[t]+dt[t]:
                    break
    return ans

def restore_on_off(ans,on_off,on,off):#可以接受小数与负数
    N=ans.shape[0]
    T=ans.shape[1]
    for i in range(N):
        t=0
        while t<T:#开机时长不够
            cnt1=0
            l=0
            while t+l<T and ans[i,t+l]==1:
                l+=1
                cnt1+=1
            if t+l>=T:
                break
            if cnt1>0 and t==0:
                cnt1+=max(0,on_off[i])
            if cnt1>0 and cnt1<on[i]:
                res = on[i]-cnt1
                dealed=0
                for ll in range(1,res+1):#往前开，遇到-1，1就停止
                    idx = t-ll
                    if idx<0 or ans[i,idx]==-1 or ans[i,idx]==1:
                        break
                    dealed+=1
                    ans[i,idx]=1
                res-=dealed
                for ll in range(1,res+1):#往后开不可能遇到-1，遇到1停止
                    idx = t+l+ll
                    if idx>=T or ans[i,idx]==1:
                        break
                    ans[i,idx]=1
            t+=l
            while t<T and ans[i,t]!=1:
                t+=1
        t=0
        while t<T:#关机时长不够
            cnt0=0
            l=0
            while t+l<T and ans[i,t+l]<1:
                l+=1
                cnt0+=1
            if t+l>=T:
                break
            if cnt0>0 and t==0:
                cnt0+=max(0,-on_off[i])

            if cnt0>0 and cnt0<off[i]:
                
                for ll in range(l):
                    ans[i,t+ll]=1
            t+=l
            while t<T and ans[i,t]>=1:
                t+=1
    return ans

def restore_shutdown(ans,m):
    N=ans.shape[0]
    T=ans.shape[1]
    
    r=m.relax()
    for i in range(N):
        for t in range(T):
            r.addConstr(m.getVarByName(f'u[{i},{t}]')==ans[i,t])
    r.optimize()

def early_startup(ans,res,t,l2r,su):
    N=ans.shape[0]
    #开机向前延长且前面满足最小开机时间
    sum=0
    for i in range(N):
        if l2r[i,t]<0:
            res-=su[i]
            sum+=su[i]
            ans[i,t]=1
        if res<=0:
            break
    return ans,sum


def delay_shutdown(ans,res,t,r2l,sd):
    N=ans.shape[0]
    #开机向后延长且后面满足最小开机时间
    sum=0
    for i in range(N):
        if r2l[i,t]<0:
            res-=sd[i]
            sum+=sd[i]
            ans[i,t]=1
        if res<=0:
            break
    return ans,sum

        

def com_cont_on_off(ans,on_off,off):
    N=ans.shape[0]
    T=ans.shape[1]
    r2l_off = np.zeros_like(ans)#表示还需要关机几个时段，0以下表示可以开机
    l2r_off = np.zeros_like(ans)#表示还需要关机几个时段，0以下表示可以开机
    for i in range(N):
        if on_off[i]<0:
            l2r_off[i,0]=off[i]+on_off[i]-1
        elif ans[i,0]<=0:
            l2r_off[i,0]=off[i]-1
        for t in range(1,T):
            if ans[i,t-1]<1 and ans[i,t]<1:
                l2r_off[i,t]=l2r_off[i,t-1]-1
            elif ans[i,t-1]==1 and ans[i,t]<1:
                l2r_off[i,t]=off[i]-1
    for i in range(N):
        if ans[i,T-1]<1:
            r2l_off[i,T-1]=-1
        for t in range(T-2,-1,-1):
            if ans[i,t+1]<1 and ans[i,t]<1 and ans[i,t]>=0:
                r2l_off[i,t]=r2l_off[i,t+1]-1
            elif ans[i,t+1]==1 and ans[i,t]<1:
                r2l_off[i,t]=off[i]-1
    return r2l_off,l2r_off

def restore_ramp(u_close,Dt,Ui0,Pi0,Pidown,Piup,ThPimin,ThPimax,Pistartup,Pishutdown,on_off,off):
    u = u_close.copy()
    u[u < 0.9+(1e-5)] = 0
    N=u.shape[0]
    T=u.shape[1]
    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.start()
        m = gp.Model(env=env)
    p = m.addVars(N, T, vtype=GRB.CONTINUOUS, name='p')

    m.addConstrs((u[i,t]*ThPimin[i] - p[i,t] <= 0  for i in range(N) for t in range (T)), name="Unit_generation_limits1" )
    m.addConstrs((p[i,t] <= u[i,t]*ThPimax[i]  for i in range(N) for t in range (T)), name="Unit_generation_limits2" )
    m.addConstrs((p[i,t]-(p[i,t-1]if t>0 else Pi0[i]) <= (u[i,t-1] if t>0 else Ui0[i])*Piup[i] + (u[i,t]-(u[i,t-1] if t>0 else Ui0[i]))*Pistartup[i] +(1-u[i,t])*ThPimax[i]  for i in range(N) for t in range(T)),name="Ramp_rate_limits1" )
    m.addConstrs(((p[i,t-1]if t>0 else Pi0[i])-p[i,t] <= u[i,t]*Pidown[i] + ((u[i,t-1] if t>0 else Ui0[i])-u[i,t])*Pishutdown[i] +(1-(u[i,t-1] if t>0 else Ui0[i]))*ThPimax[i]  for i in range(N) for t in range(T)),name="Ramp_rate_limits2")

    m.addConstrs((gp.quicksum(p[i, t] for i in range(N)) - Dt[t]  <= 0 for t in range(T)),name="Power_balance_constrains")

    m.setObjective(gp.quicksum(Dt[t] - gp.quicksum(p[i,t] for i in range(N)) for t in range(T)), GRB.MINIMIZE)
    m.update()        
    m.optimize()
    p_sum=[0]*T
    for i in range(N):
        for t in range(T):
            p_sum[t]+=p[i,t].x
    r2l,l2r = com_cont_on_off(u_close,on_off,off)
    #低成本修复爬坡，不保证完成修复
    for t in range(T):
        if p_sum[t]+1e-5<Dt[t]:#ans,res,t,r2l,sd
            u_close,res = delay_shutdown(u_close,Dt[t]-p_sum[t],t,r2l,Pishutdown)
            p_sum[t]+=res
    for t in range(T-1,-1,-1):
        if p_sum[t]+1e-5<Dt[t]:
            u_close,res = early_startup(u_close,Dt[t]-p_sum[t],t,l2r,Pistartup)
            p_sum[t]+=res
    #高成本修复爬坡，保证完成修复
    for t in range(T):
        if p_sum[t]+1e-5<Dt[t]:
            # for i in range(N-1,-1,-1):                #按优先顺序法固定
            #     if u_close[i,t]>=0 and u_close[i,t]<1:#不能开启必关机组
            #         u_close[i,t]=1                      #后面考虑先开预测值大的机组
            #         p_sum[t]+=Pistartup[i]
            #         if p_sum[t]>=Dt[t]:
            #             break
            p_list=[]
            for i in range(N):
                if u_close[i,t]>=0 and u_close[i,t]<1:
                    p_list.append((u_close[i,t],i))
            p_list.sort(key=lambda x:x[0],reverse=True)
            for p,i in p_list:
                u_close[i,t]=1
                p_sum[t]+=Pistartup[i]
                if p_sum[t]>=Dt[t]:
                    break
    return u_close

def restore(sol, uc, data):
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']
    shut_down = uc.Pishutdown
    startup = uc.Pistartup
    on = uc.ThTime_on_min
    off = uc.ThTime_off_min
    pmax = uc.ThPimax
    pmin = uc.ThPimin
    ramp_up = uc.Piup
    ramp_down = uc.Pidown
    sol = restore_initial(sol,p0,ramp_down,shut_down,on_off,on,off)
    sol[sol >= 0.9] = 1
    sol = restore_spin(sol,Spin,Dt,pmax)
    sol = restore_on_off(sol,on_off,on,off)
    sol = restore_ramp(sol,Dt,u0,p0,ramp_down,ramp_up,pmin,pmax,startup,shut_down,on_off,off)
    sol = restore_on_off(sol,on_off,on,off)
    sol[sol < 1-(1e-5)] = 0
    return sol

def solve(m,sol):
    m1 = m.copy()
    u = m1.getVars()[:len(sol)]
    for i in range(len(sol)):
        m1.addConstr(u[i]==sol[i],name=f'fix_u[{i}]')
    m1.optimize()
    if m1.status==3:
        return -1
    return m1.objVal

def restore_num(sol,uc,data):
    Dt = data['Dt']
    Spin = data['Spin']
    u0 = data['u0']
    p0 = data['p0']
    on_off = data['on_off']

    nums = np.array(uc.nums)

    shut_down = uc.Pishutdown
    startup = uc.Pistartup
    on = uc.ThTime_on_min
    off = uc.ThTime_off_min
    pmax = uc.ThPimax
    pmin = uc.ThPimin
    ramp_up = uc.Piup
    ramp_down = uc.Pidown

# def solve_num(m,sol):