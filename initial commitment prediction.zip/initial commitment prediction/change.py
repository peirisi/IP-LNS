
import os
import torch
import torch_geometric

instance = '80_c11_based_8_std'
uc_model = '3bin'
model = 'tripartite_one_variable'

# file_dir='tripartite_one_variable'
# dirs = ['test']
# ucmodels = ['3bin']
# for ucmodel in ucmodels:
#     for dir in dirs:
#         path = f'datasets/{instance}/{ucmodel}/{file_dir}/{dir}/'
#         files = os.listdir(path)
        
#         for file in files:
#             data = torch.load(path+file)
#             # graph = data['graph']
#             del data['constraints']
#             del data['variables']
#             # data['constraints']=graph['constraints'].info
#             # graph['constraints'].info = None
#             # data['variables']=graph['variables'].info
#             # graph['variables'].info = None
#             # print(data)
#             # break
#             torch.save(data,path+file)

data = torch.load(f'datasets/{instance}/{uc_model}/{model}/test/7_0.pt')
print(data)
from rgcn_dataset import GraphDataset
train_data = GraphDataset(f'./datasets/{instance}/{uc_model}/{model}/test/')
train_iter = torch_geometric.loader.DataLoader(
    train_data, batch_size = 1, shuffle = True,
    num_workers = 1, pin_memory=True)
for data in train_iter:
    print(data)
    break