import sys
sys.path.append('/home/peilun/ml4uc_experiment/evaluate')
import evaluate_time_month
import time
import numpy as np
import os
from rich.progress import Progress, BarColumn, TimeRemainingColumn, TimeElapsedColumn
from evaluate.show_in_excel import write_month_excel
from concurrent.futures import ThreadPoolExecutor
from multiprocessing import Pool
import multiprocessing as mp
# mp.set_start_method('spawn', force=True)
# begin = time.time()
# evaluate_time_opt.eva_origin('10_std',Core=60,TLE=3600)
# print(time.time()-begin)

k = [1, 0.95, 0.9, 0.85, 0.8, 0.7, 0.5, 0.3, 0]
k.reverse()
# print(k)
# l = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
# l=[0]

# instance = '10_std'
# instance = '10_5*2_std'
# model = '5_std'
instance = '50_0_1_w'
N = int(instance.split('_')[0])
# N=5
T = 24
Core = 60
TLE = 120
GAP = 1e-3
# month = 1
filename=f'{instance}_month'
# 创建后面的文件夹
os.makedirs(f'evaluate/{filename}/', exist_ok=True)
os.makedirs(f'evaluate/{filename}/1bin/', exist_ok=True)
os.makedirs(f'evaluate/{filename}/3bin/', exist_ok=True)

def cal(np_data):
    num_samples = len(np_data)
    infeasible_count = 0
    total_time = 0.0
    total_function_value = 0.0
    
    for function_value, time in np_data:
        if function_value == -1:
            infeasible_count += 1
        else:
            total_time += time
            total_function_value += function_value

    infeasible_rate = infeasible_count / num_samples if num_samples > 0 else 0
    average_time = total_time / (num_samples - infeasible_count) if (num_samples - infeasible_count) > 0 else 0
    average_function_value = total_function_value / (num_samples - infeasible_count) if (num_samples - infeasible_count) > 0 else 0
    return infeasible_rate, average_time, average_function_value 



# with Progress(
#         "[progress.description]{task.description}({task.completed}/{task.total})",
#         BarColumn(),
#         "[progress.percentage]{task.percentage:>3.2f}%",
#         TimeElapsedColumn(),
#         '<',
#         TimeRemainingColumn(),
# ) as progress:
#     move = [(instance, k1, TLE, GAP, month,progress) for k1 in k for month in range(1,11)]
#     for move_item in  progress.track(move, total=len(move),description='[cyan]Processing ps1bin files...'):
#         k, month, result_1bin, result_3bin = evaluate_time_month.eva_psa(move_item)
        

#         result_3bin = np.array(result_3bin)
#         infeasible_rate, average_time, average_function_value = cal(result_3bin)
#         print(k,month,average_time)
#         np.save(f'evaluate/{filename}/3bin/k_{k}_month_{month}_3bin.npy', result_3bin)
#         write_month_excel('3bin', filename)







# 评估机器学习加速
#多线程
with Progress(
        "[progress.description]{task.description}({task.completed}/{task.total})",
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.2f}%",
        TimeElapsedColumn(),
        '<',
        TimeRemainingColumn(),
) as progress, ThreadPoolExecutor(max_workers=Core) as executor:
    move = [(instance, k1, TLE, GAP, month,progress) for k1 in k for month in range(1,11)]
    for k,month,result_1bin,result_3bin in progress.track(executor.map(evaluate_time_month.eva_psa, move), total=len(move),description='[cyan]Processing ps1bin files...'):
        
        # result_1bin = np.array(result_1bin)
        # np.save(f'evaluate/{filename}/1bin/k_{k}_month_{month}_1bin.npy', result_1bin)

        result_3bin = np.array(result_3bin)
        infeasible_rate, average_time, average_function_value = cal(result_3bin)
        print(k,month,infeasible_rate,average_time)
        np.save(f'evaluate/{filename}/3bin/k_{k}_month_{month}_3bin.npy', result_3bin)
        # print(f'完成{k}{month}')
        # write_month_excel('1bin', filename)
        write_month_excel('3bin', filename)

#多进程
# if __name__ == '__main__':
#     with Progress(
#             "[progress.description]{task.description}({task.completed}/{task.total})",
#             BarColumn(),
#             "[progress.percentage]{task.percentage:>3.2f}%",
#             TimeElapsedColumn(),
#             '<',
#             TimeRemainingColumn(),
#     ) as progress:
#         move = [(instance, k1, TLE, GAP, month, progress) for k1 in k for month in range(1,11)]
#         # move.append((instance, 1.1, 0, N, T, TLE, GAP))

#         with Pool(processes=Core) as pool:
#             results = list(progress.track(pool.imap(evaluate_time_month.eva_psa, move), total=len(move),description='[cyan]Processing ps files...'))

#         for k,month,result_1bin,result_3bin in results:
#             result_1bin = np.array(result_1bin)
#             np.save(f'evaluate/{filename}/1bin/k_{k}_month_{month}_1bin.npy', result_1bin)

#             result_3bin = np.array(result_3bin)
#             np.save(f'evaluate/{filename}/3bin/k_{k}_month_{month}_3bin.npy', result_3bin)
#     write_month_excel('1bin', filename)
#     write_month_excel('3bin', filename)




# data = np.load("1bin/k1_1.1_lsr_0_1bin.npy")
# print(data.shape)
# write_data_to_excel('1bin', instance)
# write_data_to_excel('3bin', instance)



