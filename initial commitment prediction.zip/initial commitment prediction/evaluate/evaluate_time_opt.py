import sys
sys.path.append('/home/peilun/ml4uc_experiment')

# from model.hand_made import GNNPolicy
from model.gcn_gat import GNNPolicy as GATPolicy
from model.gcn import GNNPolicy as GCNPolicy
import os
import torch
from utilities import *
import time
from gurobipy import GRB
import gurobipy as gp
# from rich.progress import Progress
from rich.progress import Progress, BarColumn, SpinnerColumn, TimeRemainingColumn, TimeElapsedColumn
from concurrent.futures import ThreadPoolExecutor



def ps_accelerate_old(G):
    file,k1,Predict_model,local_search_range,TLE,GAP=G
    if k1<=1:
        k0=0
    else:
        k0=-1
    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.setParam('MIPGap', GAP)
        env.start()
        m = gp.read(file,env)
        A_indices, A_values, v_nodes, c_nodes, b_vars=get_fea(m)

        # Predict_model = GNNPolicy()
        # state_dict = torch.load(model_save_path)
        # Predict_model.load_state_dict(state_dict)
        # for i in range(24*1,24*2):
        #     b_vars[i]=0
        
        sol = Predict_model(c_nodes, A_indices, A_values, v_nodes).sigmoid()        
        instance_variabels = m.getVars()
        alphas = []
        for i,v in enumerate(instance_variabels):
            if b_vars[i]==1:
                if sol[i]>=k1 or sol[i]<=k0:
                    x_star = 1 if sol[i]>=k1 else 0
                    tmp_var = m.addVar(vtype=GRB.CONTINUOUS,name=f'alpha{v.VarName}')
                    alphas.append(tmp_var)
                    m.addConstr(tmp_var >= v - x_star, name=f'alpha_up_{v.VarName}')
                    m.addConstr(tmp_var >= x_star - v, name=f'alpha_dowm_{v.VarName}')
        all_tmp = 0
        for tmp in alphas:
            all_tmp += tmp
        m.addConstr(all_tmp <= local_search_range, name="sum_alpha")
        m.update()
        # m.Params.Threads = 1
        m.Params.TimeLimit = TLE
        begin = time.time()
        m.optimize()
        if m.Status==2 or m.Status ==9:
            return m.objVal,time.time()-begin,len(alphas)/b_vars.sum()
        else:
            return -1,time.time()-begin,len(alphas)/b_vars.sum()

def ps_accelerate(G):
    edge_index=None
    if len(G)==7:
        instance,file,k,Predict_model,TLE,GAP,edge_index=G
    else:
        instance,file,k,Predict_model,TLE,GAP=G


    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.setParam('MIPGap', GAP)
        env.start()
        m = gp.read(file,env)
        f = m.getObjective()

        if k>0:
            A_indices, A_values, v_nodes, c_nodes, b_vars=get_fea(m)
            if edge_index is not None:
                sol = Predict_model(c_nodes, A_indices, A_values, v_nodes, edge_index).sigmoid()
            else:
                sol = Predict_model(c_nodes, A_indices, A_values, v_nodes).sigmoid()

            #只保留b_vars=1的位置的变量        
            sol = sol[b_vars==1]
            sol = he_fs(m,sol,k,instance)
            sol = remove_initial(sol,m)
            day = int(file.split('/')[4].split('_')[0])
            sol = restore_on_off(sol,instance,day)

            # m = soft_fix_variable(m,sol)
            m = fix_variable(m,sol)

        # m.Params.Threads = 1
        m.Params.TimeLimit = TLE
        begin = time.time()
        m.optimize()
        if m.Status==2 or m.Status ==9:
            return f.getValue(),time.time()-begin
        else:
            return -1,time.time()-begin


def eva_psa_gcn(G):
    #model, instance, k1, N, T, TLE, GAP
    model,instance,k1,N,T,TLE,GAP,progress = G 
    #设置数据集路径
    data_path_3bin = f'datasets/{instance}/3bin/test/'
    files_3bin = os.listdir(data_path_3bin)
    lp_files_3bin = [f for f in files_3bin if f.endswith('.lp')]
  
    edge_index = get_edge_index(N,T)
    #设置模型路径
    model_save_path_3bin = f'model_save/3bin_{model}_gcn/model_best.pth'


    model_3bin = GCNPolicy()
    state_3bin_dict = torch.load(model_save_path_3bin, map_location=torch.device('cpu'))
    model_3bin.load_state_dict(state_3bin_dict)
    model_3bin.eval()

    results_3bin = []
    move_3bin = [(instance,os.path.join(data_path_3bin, file_3bin),k1,model_3bin,TLE,GAP) for file_3bin in lp_files_3bin]
    task1 = progress.add_task(f'Processing  k:{k1}files...',total=len(move_3bin))
    
    for move in move_3bin:
        result = ps_accelerate(move)
        results_3bin.append(result)
        progress.update(task1,advance=1)


    return k1, results_3bin
        
def eva_psa_gat(G):
    #model, instance, k1, N, T, TLE, GAP
    model,instance,k1,N,T,TLE,GAP,progress = G 
    #设置数据集路径
    data_path_3bin = f'datasets/{instance}/3bin/test/'
    files_3bin = os.listdir(data_path_3bin)
    lp_files_3bin = [f for f in files_3bin if f.endswith('.lp')]
  
    edge_index = get_edge_index(N,T)
    #设置模型路径
    model_save_path_3bin = f'model_save/3bin_{model}_gat/model_best.pth'


    model_3bin = GATPolicy()
    state_3bin_dict = torch.load(model_save_path_3bin, map_location=torch.device('cpu'))
    model_3bin.load_state_dict(state_3bin_dict)
    model_3bin.eval()

    results_1bin = []
    results_3bin = []
    # move_1bin = [(os.path.join(data_path_1bin, file_1bin),k1,model_1bin,edge_index,ls_range,TLE,GAP) for file_1bin in lp_files_1bin]
    move_3bin = [(instance,os.path.join(data_path_3bin, file_3bin),k1,model_3bin,TLE,GAP,edge_index) for file_3bin in lp_files_3bin]
    task1 = progress.add_task(f'Processing  k:{k1}files...',total=len(move_3bin))
    
    for move in move_3bin:
        result = ps_accelerate(move)
        results_3bin.append(result)
        progress.update(task1,advance=1)


    return k1, results_3bin

# instance = '10_std_opt'
# N = int(instance.split('_')[0])
# # N=5
# T = 24
# Core = 1
# TLE = 60



# begin = time.time()
# move=(instance,0.99,2,5,24,1,3600)
# k,l,result_1bin,result_3bin = eva_psa(move)
# # print(time.time()-begin)
# print(result_1bin)
# print(result_3bin)

# or_1bin = eva_origin(instance='50_0_1_w',Core=1,TLE=60)
# print(or_1bin)
# ps_1bin = eva_psa(instance='50_0_1_w',k1=1,ls_range=2,N=5,T=24,TLE=60)
# print(ps_1bin)
