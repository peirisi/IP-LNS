import os
import numpy as np
import pandas as pd

# 指定目录



def cal(np_data):
    num_samples = len(np_data)
    infeasible_count = 0
    total_time = 0.0
    total_function_value = 0.0
    # print(np_data)
    for function_value, time in np_data:
        if function_value == -1:
            infeasible_count += 1
        else:
            total_time += time
            total_function_value += function_value

    infeasible_rate = infeasible_count / num_samples if num_samples > 0 else 0
    average_time = total_time / (num_samples - infeasible_count) if (num_samples - infeasible_count) > 0 else 0
    average_function_value = total_function_value / (num_samples - infeasible_count) if (num_samples - infeasible_count) > 0 else 0
    return infeasible_rate, average_time, average_function_value 

def write_data_to_excel(model, instance):
    # model = '1bin'
    # instance = '5_std'
    directory = f'evaluate/{instance}/{model}/'

    # 初始化一个字典来存储数据
    statistics = {
        'k1': [],
        'infeasible_rate': [],
        'average_time': [],
        'average_function_value': []
    }
    # 遍历目录
    for filename in os.listdir(directory):
        if filename.endswith(".npy"):
            # 从文件名中提取k1的值
            parts = filename.split('_')
            k1_value = float(parts[1])
            # 读取Numpy数据
            file_path = os.path.join(directory, filename)
            np_data = np.load(file_path)
            infeasible_rate,average_time,average_function_value = cal(np_data)
            statistics['k1'].append(k1_value)
            statistics['infeasible_rate'].append(infeasible_rate)
            statistics['average_time'].append(average_time)
            statistics['average_function_value'].append(average_function_value)


    # 创建一个 DataFrame 来存储统计数据
    df = pd.DataFrame(statistics)

    # 创建 ExcelWriter
    with pd.ExcelWriter(f'{instance}_{model}_statistics_summary.xlsx', engine='xlsxwriter') as writer:
        # 写入不可行率数据
        df_infeasible_rate = df.pivot_table(index='k1', values='infeasible_rate')
        df_infeasible_rate.to_excel(writer, sheet_name='Infeasible Rate')

        # 写入平均时间数据
        df_average_time = df.pivot_table(index='k1', values='average_time')
        df_average_time.to_excel(writer, sheet_name='Average Time')

        # 写入平均目标函数数据
        df_average_function_value = df.pivot_table(index='k1', values='average_function_value')
        df_average_function_value.to_excel(writer, sheet_name='Average Function Value')


    print(f'{instance}_{model}_statistics_summary.xlsx')

def write_month_excel(model, instance):
    # model = '1bin'
    # instance = '5_std'
    directory = f'evaluate/{instance}/{model}'
    print(directory)

    # 初始化一个字典来存储数据
    statistics = {
        'k': [],
        'month': [],
        'infeasible_rate': [],
        'average_time': [],
        'average_function_value': []
    }
    # 遍历目录
    for filename in os.listdir(directory):
        if filename.endswith(".npy"):
            # 从文件名中提取k1的值
            parts = filename.split('_')
            k_value = float(parts[1])
            month_value = float(parts[3])
            # 读取Numpy数据
            file_path = os.path.join(directory, filename)
            np_data = np.load(file_path)
            infeasible_rate,average_time,average_function_value = cal(np_data)
            statistics['k'].append(k_value)
            statistics['month'].append(month_value)
            statistics['infeasible_rate'].append(infeasible_rate)
            statistics['average_time'].append(average_time)
            statistics['average_function_value'].append(average_function_value)

            
    # 创建一个 DataFrame 来存储统计数据
    df = pd.DataFrame(statistics)

    # 创建 ExcelWriter
    with pd.ExcelWriter(f'{instance}_{model}_statistics_summary.xlsx', engine='xlsxwriter') as writer:
        # 写入不可行率数据
        df_infeasible_rate = df.pivot(index='k', columns='month', values='infeasible_rate')
        df_infeasible_rate.to_excel(writer, sheet_name='Infeasible Rate')

        # 写入平均时间数据
        df_average_time = df.pivot(index='k', columns='month', values='average_time')
        df_average_time.to_excel(writer, sheet_name='Average Time')

        # 写入平均目标函数数据
        df_average_function_value = df.pivot(index='k', columns='month', values='average_function_value')
        df_average_function_value.to_excel(writer, sheet_name='Average Function Value')

    print(f'{instance}_{model}_statistics_summary.xlsx')

# instance = '50_0_1_w'
# filename=f'{instance}_month'

# write_month_excel('1bin', filename)
# write_month_excel('3bin', filename)
# np_data = np.load('evaluate/50_0_1_w_month/1bin/k_1_month_1_1bin.npy')
# print(np_data)
# for function_value, time in np_data:
#     print(function_value,time)