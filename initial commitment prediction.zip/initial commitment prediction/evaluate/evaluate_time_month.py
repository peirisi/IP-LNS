import sys
sys.path.append('/home/peilun/ml4uc_experiment')

# from model.hand_made import GNNPolicy
from model.gcn import GNNPolicy
import os
import torch
from utilities import *
import time
from gurobipy import GRB
import gurobipy as gp
# from rich.progress import Progress
from rich.progress import Progress, BarColumn, SpinnerColumn, TimeRemainingColumn, TimeElapsedColumn
from concurrent.futures import ThreadPoolExecutor




def ps_accelerate(G):
    instance,file,k,Predict_model,TLE,GAP=G

    with gp.Env(empty=True) as env:
        env.setParam('OutputFlag', 0)
        env.setParam('MIPGap', GAP)
        env.start()
        m = gp.read(file,env)
        f = m.getObjective()

        if k>0:
            A_indices, A_values, v_nodes, c_nodes, b_vars=get_fea(m)

            sol = Predict_model(c_nodes, A_indices, A_values, v_nodes).sigmoid()
            #只保留b_vars=1的位置的变量        
            sol = sol[b_vars==1]
            sol = he_fs(m,sol,k,instance)
            sol = remove_initial(sol,m)
            day = int(file.split('/')[4].split('_')[0])
            sol = restore_on_off(sol,instance,day)

            # m = soft_fix_variable(m,sol)
            m = fix_variable(m,sol)

        m.Params.Threads = 1
        m.Params.TimeLimit = TLE
        begin = time.time()
        m.optimize()
        if m.Status==2 or m.Status ==9:
            return f.getValue(),time.time()-begin
        else:
            return -1,time.time()-begin


        
def eva_psa(G):
    instance,k,TLE,GAP,month,progress = G 
    #设置数据集路径
    # data_path_1bin = f'newdatasets/{instance}/1bin/test/{month+1}'
    # files_1bin = os.listdir(data_path_1bin)
    data_path_3bin = f'newdatasets/{instance}/3bin/test/{month+1}'
    files_3bin = os.listdir(data_path_3bin)

    # lp_files_1bin = [f for f in files_1bin if f.endswith('.lp')][::5]
    lp_files_3bin = [f for f in files_3bin if f.endswith('.lp')][::5]
    
  
    #设置模型路径
    # model_save_path_1bin = f'model_save/1bin_{instance}_{month}/model_best.pth'

    # model_save_path_3bin = f'./model_save/3bin_10_std/model_best.pth'
    model_save_path_3bin = f'model_save/3bin_{instance}_{month}/model_best.pth'


    # model_1bin = GNNPolicy()
    # state_1bin_dict = torch.load(model_save_path_1bin, map_location=torch.device('cpu'))
    # model_1bin.load_state_dict(state_1bin_dict)
    # model_1bin.eval()

    model_3bin = GNNPolicy()
    state_3bin_dict = torch.load(model_save_path_3bin, map_location=torch.device('cpu'))
    model_3bin.load_state_dict(state_3bin_dict)
    model_3bin.eval()

    results_1bin = []
    results_3bin = []
    # move_1bin = [(instance,os.path.join(data_path_1bin, file_1bin),k,model_1bin,TLE,GAP) for file_1bin in lp_files_1bin]
    move_3bin = [(instance,os.path.join(data_path_3bin, file_3bin),k,model_3bin,TLE,GAP) for file_3bin in lp_files_3bin]
    task1 = progress.add_task(f'Processing month:{month} k:{k}files...',total=len(move_3bin))
    # for move in move_1bin:
    #     result = ps_accelerate(move)
    #     results_1bin.append(result)
    #     progress.update(task1,advance=1)
    # print(move_3bin)
    for move in move_3bin:
        result = ps_accelerate(move)
        results_3bin.append(result)
        progress.update(task1,advance=1)
    #结束后进度条消失
    progress.remove_task(task1)

    return k, month, results_1bin, results_3bin

# instance = '10_std_opt'
# N = int(instance.split('_')[0])
# # N=5
# T = 24
# Core = 1
# TLE = 60



# begin = time.time()
# move=(instance,0.99,2,5,24,1,3600)
# k,l,result_1bin,result_3bin = eva_psa(move)
# # print(time.time()-begin)
# print(result_1bin)
# print(result_3bin)

# or_1bin = eva_origin(instance='50_0_1_w',Core=1,TLE=60)
# print(or_1bin)
# ps_1bin = eva_psa(instance='50_0_1_w',k1=1,ls_range=2,N=5,T=24,TLE=60)
# print(ps_1bin)
