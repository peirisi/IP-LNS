import numpy as np
file = 'UC_AF/50_0_1_w.mod'

class UC:

    def __init__(self,file):
        with open(file, "r") as f:
            lines = f.readlines()

        self.HorizonLen=np.array(int(lines[1].split()[1]))      #时段
        self.NumThermal=np.array(int(lines[2].split()[1]))      #火电机组数量
        self.PD=np.array([float(x) for x in lines[10].split()])     #负荷
        self.spin=np.array([float(x) for x in lines[12].split()])     #备用

        self.units=[[float(x) for x in line.split()] for line in lines[14:14+self.NumThermal*2:2]]#读取机组信息
        self.gamma = np.array([row[1] for row in self.units])     #机组参数
        self.beta = np.array([row[2] for row in self.units])      #机组参数
        self.alpha = np.array([row[3] for row in self.units])     #机组参数
        self.p_low = np.array([row[4] for row in self.units])     #发电下界
        self.p_up = np.array([row[5] for row in self.units])      #发电上界
        self.time_on_off_ini = np.array([int(row[6]) for row in self.units])      #初始状态前以及开机/停机的时间
        self.time_min_on = np.array([int(row[7]) for row in self.units])          #最小开机时间
        self.time_min_off = np.array([int(row[8]) for row in self.units])         #最小关机时间
        self.fixedCost4startup = np.array([row[13] for row in self.units])        #启动费用
        self.p_initial = np.array([row[15] for row in self.units])                #初始发电功率
        self.u_initial = np.array([1 if init>0 else 0 for init in self.p_initial])#初始运行状态
        self.RampConstraints=[[x for x in line.split()] for line in lines[15:15+self.NumThermal*2:2]]#读取爬坡信息
        self.p_rampup = np.array([float(row[1]) for row in self.RampConstraints])          #上坡功率
        self.p_rampdown = np.array([float(row[2]) for row in self.RampConstraints])        #下坡功率

        self.p_startup = self.p_low
        self.p_shutdown = self.p_low

        self.Hot_cost = self.fixedCost4startup      #热启动价格
        self.Cold_cost = self.fixedCost4startup      #冷启动价格


        if 'std' in file:
            self.Cold_hour = np.array([row[16] for row in self.units])                #冷却时间
            # if '5_std' in file:
            if '5_std' not in file:
                self.Cold_cost = np.array([cost*2 for cost in self.fixedCost4startup])#冷启动价格
        else:
            self.Cold_hour = np.ones(self.NumThermal)

        
        self.u0=np.array([1 if init>0 else 0 for init in self.p_initial])             #初始运行状态

        if '8_std' in file:
            tmp = [ 0.71, 0.65, 0.62,  0.6,  0.58,  0.58,  0.6,  0.64,
                    0.73, 0.8,  0.82,  0.83,   0.82, 0.8,  0.79,  0.79,
                    0.83, 0.91, 0.9,  0.88,   0.85,  0.84,  0.79,  0.74]
            self.PD = np.array([sum(self.p_up)*p for p in tmp])
            self.spin = np.array([pd*0.03 for pd in self.PD])
        
        self.projected = 0
        self.expended  = 0

# a = UC(file)
# print(a.p_initial)