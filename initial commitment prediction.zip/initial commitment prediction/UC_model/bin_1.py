import gurobipy as gp
import numpy as np
from gurobipy import GRB

from readdataUC import UC


class Bin1:
    def __init__(self,file):
        dataUC = UC(file)
        self.Alpha = dataUC.alpha                           #火电机组发电函数系数Alpha--N*1矩阵
        self.Beta = dataUC.beta                           #火电机组发电函数系数Beta--N*1矩阵
        self.Gamma = dataUC.gamma                           #火电机组发电函数系数Gamma--N*1矩阵
        self.ThPimin = dataUC.p_low                         #火电机组发电功率下界--N*1矩阵
        self.ThPimax = dataUC.p_up                          #火电机组发电功率上界--N*1矩阵
        self.Piup = dataUC.p_rampup                         #火电机组上坡功率上界--N*1矩阵
        self.Pidown = dataUC.p_rampdown                     #火电机组下坡功率上界--N*1矩阵
        self.N = dataUC.NumThermal.tolist()                          #火电机组数量--1*1矩阵
        self.T = dataUC.HorizonLen.tolist()                         #时间段数--1*1矩阵
        self.Dt = [0 for i in range(self.T)]                                 #负载需求--T*1矩阵
        self.Spin = [0 for i in range(self.T)]                             #旋转热备用--T*1矩阵
        self.ThTime_on_off_init = dataUC.time_on_off_ini    #火电机组在初始状态前已经开机/停机的时间--N*1矩阵
        self.ThTime_on_min = dataUC.time_min_on             #火电机组最小开机时间--N*1矩阵
        self.ThTime_off_min = dataUC.time_min_off           #火电机组最小停机时间--N*1矩阵
        self.coldi = dataUC.Cold_cost           #火电机组冷启动费用--N*1矩阵
        self.hoti = dataUC.Hot_cost             #火电机组热启动费用--N*1矩阵
        self.Tcoldi = dataUC.Cold_hour.astype(int)          #火电机组冷启动时间--N*1矩阵
        self.Pistartup = dataUC.p_startup                   #火电机组开机功率--N*1矩阵
        self.Pishutdown = dataUC.p_shutdown                 #火电机组关机功率--N*1矩阵
        self.NodeNum=dataUC.NumThermal
        self.Ui0=dataUC.u_initial                                   #机组初初始状态--N*1矩阵
        self.Pi0 = dataUC.p_initial                #火电机组机组初始功率--N*1矩阵

    def get_model(self,Dt=None,Spin=None,ThTime_on_off_init=None,Ui0=None,Pi0=None):
        if Dt is not None:
            self.Dt=Dt
        if Spin is not None:
            self.Spin=Spin
        if ThTime_on_off_init is not None:
            self.ThTime_on_off_init=ThTime_on_off_init
        if Ui0 is not None:
            self.Ui0=Ui0        
        if Pi0 is not None:
            self.Pi0=Pi0
        #电机组最小开/停机约束需要的变量                   #--N*1矩阵
        Ui = np.maximum(0,np.minimum(np.ones((self.N)) * self.T,self.Ui0 * (self.ThTime_on_min - self.ThTime_on_off_init))).astype(int)                    #--N*1矩阵 
        Li = np.maximum(0,np.minimum(np.ones((self.N)) * self.T,(np.ones((self.N)) - self.Ui0) * (self.ThTime_off_min + self.ThTime_on_off_init))).astype(int)    #--N*1矩阵
      

        Ndi=[self.ThTime_off_min[i]+self.Tcoldi[i]+1 for i in range(self.N)]
        with gp.Env(empty=True) as env:
            env.setParam('OutputFlag', 0)
            # env.setParam('LogToConsole', 1)
            env.start()
            # with gp.Model(env=env) as m:
            m = gp.Model(env=env)
            u = m.addVars(self.N,self.T,vtype=GRB.BINARY,name="u")            #N行T列
            p = m.addVars(self.N,self.T,vtype=GRB.CONTINUOUS,name="p")            #N行T列
            s = m.addVars(self.N,self.T,vtype=GRB.CONTINUOUS,name="s")            #N行T列


            m.addConstrs((-u[i,t] <= 0  for i in range(self.N) for t in range (self.T)), name="u_low" )
            m.addConstrs((u[i,t] <= 1  for i in range(self.N) for t in range (self.T)), name="u_up" )
            
            m.addConstrs((p[i,t] <= self.ThPimax[i]  for i in range(self.N) for t in range (self.T)), name="p_up" )
            m.addConstrs((-p[i,t] <= 0  for i in range(self.N) for t in range (self.T)), name="p_down" )

            #Unit generation capacity limits constrains	
            m.addConstrs((u[i,t]*self.ThPimin[i] <= p[i,t]  for i in range(self.N) for t in range (self.T)), name="Unit_generation_limits1" )
            m.addConstrs((p[i,t] <= u[i,t]*self.ThPimax[i]  for i in range(self.N) for t in range (self.T)), name="Unit_generation_limits2" )

            #Power balance constrains
            m.addConstrs((gp.quicksum(p[i,t] for i in range(self.N)) == self.Dt[t] for t in range (self.T)),name="Power_balance_constrains" )

            #System spinning reserve requirement
            m.addConstrs((-gp.quicksum(u[i,t]*self.ThPimax[i] for i in range(self.N)) <= -self.Dt[t]+self.Spin[t] for t in range (self.T)),name="System_spinning_reserve_requirement" )

            #Ramp rate limits
            m.addConstrs((p[i,t]-(p[i,t-1]if t>0 else self.Pi0[i]) <= (u[i,t-1] if t>0 else self.Ui0[i])*self.Piup[i] + (u[i,t]-(u[i,t-1] if t>0 else self.Ui0[i]))*self.Pistartup[i] +(1-u[i,t])*self.ThPimax[i]  for i in range(self.N) for t in range(self.T)),name="Ramp_rate_limits1" )
            
            m.addConstrs(((p[i,t-1]if t>0 else self.Pi0[i])-p[i,t] <= u[i,t]*self.Pidown[i] + ((u[i,t-1] if t>0 else self.Ui0[i])-u[i,t])*self.Pishutdown[i] +(1-(u[i,t-1] if t>0 else self.Ui0[i]))*self.ThPimax[i]  for i in range(self.N) for t in range(self.T)),name="Ramp_rate_limits2" )

            #Minimum up/down time constraints
            m.addConstrs((u[i,t]-(u[i,t-1] if t>0 else self.Ui0[i])<=u[i,l] for t in range(self.T) for i in range(self.N) for l in range(t+1,min(t+self.ThTime_on_min[i],self.T))),name="Minimum_up/down_time_constraints1")
            m.addConstrs(((u[i,t-1] if t>0 else self.Ui0[i])-u[i,t]<=1-u[i,l] for t in range(self.T) for i in range(self.N) for l in range(t+1,min(t+self.ThTime_off_min[i],self.T))),name="Minimum_up/down_time_constraints2")



            #Initial status of units
            m.addConstrs((u[i,t]==self.Ui0[i] for i in range(self.N) for t in range(Ui[i]+Li[i])),name="Initial_status_of_units")

            #startup cost
            m.addConstrs((-s[i,t] <= -(self.hoti[i] if l<=self.ThTime_off_min[i]+self.Tcoldi[i] else self.coldi[i])* (u[i,t]-gp.quicksum((u[i,t-j]) if t>=j else(1 if j-t<=self.ThTime_on_off_init[i] or (self.ThTime_on_off_init[i]<0 and j-t>-self.ThTime_on_off_init[i]) else 0) for j in range(1,l+1))) for i in range(self.N) for t in range(self.T) for l in [1,Ndi[i]]),name="startup_cost")

            # m.setObjective(gp.quicksum(self.Beta[i]*p[i,t] + self.Gamma[i]*p[i,t]*p[i,t] for i in range(self.N) for t in range(self.T)),GRB.MINIMIZE)
            m.setObjective(gp.quicksum(self.Alpha[i]*u[i,t] + self.Beta[i]*p[i,t] + s[i,t] for i in range(self.N) for t in range(self.T)),GRB.MINIMIZE)
            # m.setObjective(gp.quicksum(self.Alpha[i]*u[i,t] + self.Beta[i]*p[i,t] + self.Gamma[i]*p[i,t]*p[i,t] + s[i,t] for i in range(self.N) for t in range(self.T)),GRB.MINIMIZE)

            m.update()
            return m
    


# name = '5_std.mod'
# file = 'UC_AF/'+name    
# Dt=np.loadtxt('deman/pd.csv',delimiter=',',encoding='utf-8-sig')
# dataUC=UC(file)

# sys_up=sum(b3.ThPimax)*0.8
# sys_low=sys_up*0.4

# pd=(Dt-Dt.min())/(Dt.max()-Dt.min())*0.85*(sys_up-sys_low)+sys_low*1.05
# # print(pd[0])
# b1=Bin1(file)

# m = b1.get_model()
# m.optimize()