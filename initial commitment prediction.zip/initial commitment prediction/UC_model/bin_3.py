import gurobipy as gp
import numpy as np
from gurobipy import GRB


class Bin3:
    def __init__(self,dataUC):
        # dataUC = UC(file)
        self.Alpha = dataUC.alpha                           #火电机组发电函数系数Alpha--N*1矩阵
        self.Beta = dataUC.beta                           #火电机组发电函数系数Beta--N*1矩阵
        self.Gamma = dataUC.gamma                           #火电机组发电函数系数Gamma--N*1矩阵
        self.ThPimin = dataUC.p_low                         #火电机组发电功率下界--N*1矩阵
        self.ThPimax = dataUC.p_up                          #火电机组发电功率上界--N*1矩阵
        self.Piup = dataUC.p_rampup                         #火电机组上坡功率上界--N*1矩阵
        self.Pidown = dataUC.p_rampdown                     #火电机组下坡功率上界--N*1矩阵
        self.N = dataUC.NumThermal.tolist()                          #火电机组数量--1*1矩阵
        self.T = dataUC.HorizonLen.tolist()                         #时间段数--1*1矩阵
        self.Dt = [0 for i in range(self.T)]                                 #负载需求--T*1矩阵
        self.Spin = [0 for i in range(self.T)]                             #旋转热备用--T*1矩阵
        self.ThTime_on_off_init = dataUC.time_on_off_ini    #火电机组在初始状态前已经开机/停机的时间--N*1矩阵
        self.ThTime_on_min = dataUC.time_min_on             #火电机组最小开机时间--N*1矩阵
        self.ThTime_off_min = dataUC.time_min_off           #火电机组最小停机时间--N*1矩阵
        self.coldi = dataUC.Cold_cost           #火电机组冷启动费用--N*1矩阵
        self.hoti = dataUC.Hot_cost             #火电机组热启动费用--N*1矩阵
        self.Tcoldi = dataUC.Cold_hour.astype(int)          #火电机组冷启动时间--N*1矩阵
        self.Pistartup = dataUC.p_startup                   #火电机组开机功率--N*1矩阵
        self.Pishutdown = dataUC.p_shutdown                 #火电机组关机功率--N*1矩阵
        self.Ui0=dataUC.u_initial                                   #机组初初始状态--N*1矩阵
        self.Pi0 = dataUC.p_initial                #火电机组机组初始功率--N*1矩阵

    def get_model(self,Dt=None,Spin=None,ThTime_on_off_init=None,Ui0=None,Pi0=None):
        if Dt is not None:
            self.Dt=Dt
        if Spin is not None:
            self.Spin=Spin
        if ThTime_on_off_init is not None:
            self.ThTime_on_off_init=ThTime_on_off_init
        if Ui0 is not None:
            self.Ui0=Ui0        
        if Pi0 is not None:
            self.Pi0=Pi0
        #电机组最小开/停机约束需要的变量                   #--N*1矩阵
        Ui = np.maximum(0,np.minimum(np.ones((self.N)) * self.T,self.Ui0 * (self.ThTime_on_min - self.ThTime_on_off_init))).astype(int)                    #--N*1矩阵 
        Li = np.maximum(0,np.minimum(np.ones((self.N)) * self.T,(np.ones((self.N)) - self.Ui0) * (self.ThTime_off_min + self.ThTime_on_off_init))).astype(int)    #--N*1矩阵

        m = gp.Model("3-bin UC formulation")
        u = m.addVars(self.N,self.T,vtype=GRB.BINARY,name="u")            #N行T列
        s = m.addVars(self.N,self.T,vtype=GRB.BINARY,name="s")            #N行T列
        d = m.addVars(self.N,self.T,vtype=GRB.BINARY,name="d")            #N行T列
        p = m.addVars(self.N,self.T,vtype=GRB.CONTINUOUS,name="p")            #N行T列
        # p1 = m.addVars(3,self.N,self.T,vtype=GRB.CONTINUOUS,name="p1")            #N行T列
        sc = m.addVars(self.N,self.T,vtype=GRB.CONTINUOUS,name="sc")            #N行T列
        #12
        m.addConstrs((s[i,t]-d[i,t]==u[i,t]-(u[i,t-1] if t>0 else self.Ui0[i]) for i in range(self.N) for t in range (self.T)),name="state_variable")

        #Unit generation capacity limits constrains	3
        m.addConstrs((u[i,t]*self.ThPimin[i] <= p[i,t]  for i in range(self.N) for t in range (self.T)), name="Unit_generation_limits1" )
        m.addConstrs((p[i,t] <= u[i,t]*self.ThPimax[i]  for i in range(self.N) for t in range (self.T)), name="Unit_generation_limits2" )

        #Power balance constrains 4
        m.addConstrs((gp.quicksum(p[i,t] for i in range(self.N)) == self.Dt[t] for t in range (self.T)),name="Power_balance_constrains" )

        #System spinning reserve requirement 5
        m.addConstrs((gp.quicksum(u[i,t]*-self.ThPimax[i] for i in range(self.N)) <= -self.Dt[t]-self.Spin[t] for t in range (self.T)),name="System_spinning_reserve_requirement" )

        #Ramp rate limits 17 18
        m.addConstrs((p[i,t]-(p[i,t-1]if t>0 else self.Pi0[i]) <= u[i,t]*(self.Piup[i]+self.ThPimin[i]) - (u[i,t-1] if t>0 else self.Ui0[i])*self.ThPimin[i] + s[i,t]*(self.Pistartup[i]-self.Piup[i]-self.ThPimin[i])  for i in range(self.N) for t in range(self.T)),name="Ramp_rate_limits1")
        m.addConstrs(((p[i,t-1]if t>0 else self.Pi0[i])-p[i,t] <= (u[i,t-1] if t>0 else self.Ui0[i])*(self.Pidown[i]+self.ThPimin[i]) - u[i,t]*self.ThPimin[i] + d[i,t]*(self.Pishutdown[i]-self.Pidown[i]-self.ThPimin[i])  for i in range(self.N) for t in range(self.T)),name="Ramp_rate_limits2")

        #Minimum up/down time constraints 13 14
        m.addConstrs((gp.quicksum(s[i,w] for w in range(max(0,t+1-self.ThTime_on_min[i]),t+1)) <= u[i,t] for i in range(self.N) for t in range (Ui[i],self.T)),name="Minimum_up/down_time_constraints1")
        m.addConstrs((gp.quicksum(d[i,w] for w in range(max(0,t+1-self.ThTime_off_min[i]),t+1)) <= 1 - u[i,t] for i in range(self.N) for t in range (Li[i],self.T)),name="Minimum_up/down_time_constraints2")

        #Initial status of units 10
        m.addConstrs((u[i,t]==self.Ui0[i] for i in range(self.N) for t in range(Ui[i]+Li[i])),name="Initial_status_of_units")

        #startup cost 19 20
        m.addConstrs(( -sc[i,t] <= -self.hoti[i]*s[i,t] for i in range(self.N) for t in range (self.T)),name="startup_cost1")
        

        # m.setObjective(gp.quicksum(self.Alpha[i]*u[i,t] + gp.quicksum(self.c.iloc[i,k]*p1[k,i,t] for k in range(3))  + sc[i,t] for i in range(self.N) for t in range(self.T)),GRB.MINIMIZE)
        
        m.setObjective(gp.quicksum(self.Alpha[i]*u[i,t] + self.Beta[i]*p[i,t] + sc[i,t] for i in range(self.N) for t in range(self.T)),GRB.MINIMIZE)
        # m.setObjective(gp.quicksum(self.Alpha[i]*u[i,t] + self.Beta[i]*p[i,t] + self.Gamma[i]*p[i,t]*p[i,t] + sc[i,t] for i in range(self.N) for t in range(self.T)),GRB.MINIMIZE)


        m.update()
        return m

name = '50_0_1_w.mod'
file = 'UC_AF/'+name
b3=Bin3(file)
m=b3.get_model()
m.optimize()