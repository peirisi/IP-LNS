import torch
import torch_geometric


class BipartiteGraphConvolution(torch_geometric.nn.MessagePassing): # type: ignore
    """
    The bipartite graph convolution is already provided by pytorch geometric and we merely need
    to provide the exact form of the messages being passed.
    """

    def __init__(self):
        super().__init__("add")
        emb_size = 64
            
        self.feature_module_left = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size)
        )
        self.feature_module_edge = torch.nn.Sequential(
            torch.nn.Linear(1, emb_size, bias=False)
        )
        self.feature_module_right = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size, bias=False)
        )
        self.feature_module_final = torch.nn.Sequential(
            torch.nn.LayerNorm(emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
        )

        self.post_conv_module = torch.nn.Sequential(torch.nn.LayerNorm(emb_size))

        # output_layers
        self.output_module = torch.nn.Sequential(
            torch.nn.Linear(2 * emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
        )

    def forward(self, left_features, edge_indices, edge_features, right_features):
        """
        This method sends the messages, computed in the message method.
        """
        output = self.propagate(
            edge_indices,
            size=(left_features.shape[0], right_features.shape[0]),
            node_features=(left_features, right_features),
            edge_features=edge_features,
        )
        return self.output_module(
            torch.cat([self.post_conv_module(output), right_features], dim=-1)
        )


    def message(self, node_features_i, node_features_j, edge_features):
        #node_features_i,the node to be aggregated
        #node_features_j,the neighbors of the node i

        output = self.feature_module_final(
            self.feature_module_left(node_features_i)
            + self.feature_module_edge(edge_features)
            + self.feature_module_right(node_features_j)
        )

        return output
    


class GNNPolicy(torch.nn.Module):
    def __init__(self):
        super().__init__()
        emb_size = 64
        self.emb_size=emb_size
        cons_nfeats = 4
        edge_nfeats = 1
        var_nfeats = 6
        hidden_size=128
        # CONSTRAINT EMBEDDING
        self.cons_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(cons_nfeats),
            torch.nn.Linear(cons_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )

        # EDGE EMBEDDING
        self.edge_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(edge_nfeats),
        )

        # VARIABLE EMBEDDING
        self.var_embedding = torch.nn.Sequential(
            torch.nn.LayerNorm(var_nfeats),
            torch.nn.Linear(var_nfeats, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
        )
        # 
        # self.lstm_v1 = torch.nn.LSTM(num_inputs, num_hiddens, num_layers, bidirectional=True)
        self.lstm1 = torch.nn.LSTM(emb_size,hidden_size,batch_first=True,bidirectional=True)
        self.lstm_linear1 = torch.nn.Linear(hidden_size*2, emb_size)
        # self.lstm2 = torch.nn.LSTM(emb_size,hidden_size,batch_first=True,bidirectional=True)
        # self.lstm_linear2 = torch.nn.Linear(hidden_size*2, emb_size)

        self.conv_v_to_c = BipartiteGraphConvolution()
        self.conv_c_to_v = BipartiteGraphConvolution()

        

        # self.conv_v_to_c2 = BipartiteGraphConvolution()
        # self.conv_c_to_v2 = BipartiteGraphConvolution()


        self.output_module = torch.nn.Sequential(
            torch.nn.Linear(emb_size, emb_size),
            torch.nn.ReLU(),
            torch.nn.Linear(emb_size, 1, bias=False),
        )

    def forward(
        self, constraint_features, edge_indices, edge_features, variable_features
    ):
        reversed_edge_indices = torch.stack([edge_indices[1], edge_indices[0]], dim=0)
        constraint_features = self.cons_embedding(constraint_features)
        edge_features = self.edge_embedding(edge_features)
        variable_features = self.var_embedding(variable_features)


        # Two half convolutions
        constraint_features = self.conv_v_to_c(
            variable_features, reversed_edge_indices, edge_features, constraint_features
        )
        variable_features = self.conv_c_to_v(
            constraint_features, edge_indices, edge_features, variable_features
        )
        vaeiable_shape = variable_features.shape
        variable_features.reshape(-1,24,self.emb_size)
        h,_ = self.lstm1(variable_features)
        variable_features = self.lstm_linear1(h).reshape(vaeiable_shape)




        # constraint_features = self.conv_v_to_c2(
        #     variable_features, reversed_edge_indices, edge_features, constraint_features
        # )
        # variable_features = self.conv_c_to_v2(
        #     constraint_features, edge_indices, edge_features, variable_features
        # )

        # variable_features.reshape(-1,24,self.emb_size)
        # h,_ = self.lstm2(variable_features)
        # variable_features = self.lstm_linear2(h).reshape(vaeiable_shape)

        # A final MLP on the variable features
        output = self.output_module(variable_features).squeeze(-1)

        return output
