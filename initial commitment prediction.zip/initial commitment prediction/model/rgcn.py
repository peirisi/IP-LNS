from torch_geometric.nn import RGCNConv
from torch_geometric.nn import GCNConv
import torch
import copy


class RGCN(torch.nn.Module):
    def __init__(self, in_channels=64, hidden_channels=64, out_channels=1):
        # num_relations=
        super(RGCN, self).__init__()
        self.node_types=['u','p','s','Minimum_up/down_time_constraints','Unit_generation_limits','Power_balance_constrains','System_spinning_reserve_requirement','Ramp_rate_limits','Initial_status_of_units','startup_cost']
        self.init_sizes=[6,6,6,4,4,4,4,4,4,4]
        num_relations = 3*7
        # self.conv1 = RGCNConv(in_channels, hidden_channels,
        #                       num_relations=num_relations, num_bases=30)
        # self.conv2 = RGCNConv(hidden_channels, out_channels,
        #                       num_relations=num_relations, num_bases=30)
        
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, out_channels)


        self.lins = torch.nn.ModuleList()
        
        for i in range(len(self.node_types)):
            lin = torch.nn.Linear(self.init_sizes[i], in_channels)
            self.lins.append(lin)


        # self.output_module = torch.nn.Sequential(
        #     torch.nn.Linear(out_channels, out_channels),
        #     torch.nn.ReLU(),
        #     torch.nn.Linear(out_channels, 1, bias=False)
        # )

    def trans_dimensions(self, g):
        data = copy.deepcopy(g)
        for node_type, lin in zip(self.node_types, self.lins):
            data[node_type].x = lin(data[node_type].x)

        return data

    def forward(self, data, n):
        data = self.trans_dimensions(data)
        homogeneous_data = data.to_homogeneous()
        edge_index, edge_type = homogeneous_data.edge_index, homogeneous_data.edge_type  
        x = homogeneous_data.x
        x = self.conv1(x, edge_index)
        x = self.conv2(x, edge_index)
        # x = self.conv1(homogeneous_data.x, edge_index, edge_type)
        # x = self.conv2(x, edge_index, edge_type)
        x = x[:n]
        # print(x.shape)
        # x = self.output_module(x).sigmoid()
        return x.sigmoid()